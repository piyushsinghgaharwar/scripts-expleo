vuser_init()
{

	/* -----SCRIPT GLOSSARY-----*/
//	1.  "web_reg_param_ex" and "web_reg_save_param_json function is used for Capturing Possible Dynamic ids/values from server's response  to be passed in subsequent requests/URL"
//  2.  "web_reg_find is used to registed a request to find specific text in response as a check point"
// 	3.  "web_add_header is used to supply header values such as session ID
//	4.  "lr_start and lr_end_transaction is used to start and end the transactions respectively
//	5.  "any value enclosed in <> is used as parameter to supply unique values for each iteration wherever possible */
	
/* --Start of Scemario - App launch --*/

/*Correlation comment - Do not change!  Original value='-2764790703814591786' Name ='languageId' Type ='ResponseBased'*/
	web_reg_save_param_ex(
		"ParamName=languageId",
		"LB=languageId = \"",
		"RB=\";",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=No",
		LAST);

web_set_sockets_option("SSL_VERSION", "TLS1.2");

/*Correlation comment - Do not change!  Original value='04186c5b68794be61ffa6bc7fb4a478817386a94' Name ='c_KID' Type ='Manual'*/
	web_reg_save_param_ex(
		"ParamName=c_KID",
		"LB=Runs on Cyclos 4.12 (revision ",
		"RB=) registered with key 70589-51945-81612-20759",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=No",
		LAST);

lr_start_transaction("BP02_01_OpenApplication");

	web_url("Network01", 
		"URL=<p_ServerURL>/cyclos/Network01", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		EXTRARES, 
		/* ---- Extrares can be commented and Non-HTML resources can be simulated through run time settings---
		"Url=Network01/js/load-image.all.min.js?_k=04186c5b68794be61ffa6bc7fb4a478817386a94", ENDITEM,
		"Url=Network01/js/script.min.js?_k=04186c5b68794be61ffa6bc7fb4a478817386a94", ENDITEM, 
		"Url=Network01/cyclos.gwt/cyclos.gwt.nocache.js?_k=04186c5b68794be61ffa6bc7fb4a478817386a94", ENDITEM, 
		"Url=Network01/cyclos.gwt/44283D0B5AB2110F2E0E4D288EF9A291.cache.js", ENDITEM, 
		"Url=Network01/content/themes/-2764790703747482922.css?_k=04186c5b68794be61ffa6bc7fb4a478817386a94&lastModified=1562772279057", ENDITEM, 
		"Url=Network01/cyclos.gwt/clear.cache.gif", ENDITEM, 
		"Url=Network01/content/images/currentConfiguration/SYSTEM_LOGO?mod=1564996692527", ENDITEM, 
		"Url=Network01/push-notifications?clientId=c5195b36-0505-44da-88e6-6611b39bb79b_1565723237216&eventTypes=loggedOut,newMessage,newNotification,deviceConfirmation&Session-Prefix=<c_sessionID>", ENDITEM, 
		"Url=Network01/content/themes/-2764790703747482922/image?_k=04186c5b68794be61ffa6bc7fb4a478817386a94&type=DASHBOARD_ACTION&name=ACCOUNT_INFO", ENDITEM, 
		"Url=Network01/content/themes/-2764790703747482922/image?_k=04186c5b68794be61ffa6bc7fb4a478817386a94&type=DASHBOARD_ACTION&name=PAYMENT_USER_TO_USER", ENDITEM, 
		"Url=Network01/content/themes/-2764790703747482922/image?_k=04186c5b68794be61ffa6bc7fb4a478817386a94&type=DASHBOARD_ACTION&name=PAYMENT_USER_TO_SYSTEM", ENDITEM, 
		"Url=Network01/content/themes/-2764790703747482922/image?_k=04186c5b68794be61ffa6bc7fb4a478817386a94&type=DASHBOARD_ACTION&name=SEARCH_USERS", ENDITEM, 
		"Url=Network01/content/themes/-2764790703747482922/image?_k=04186c5b68794be61ffa6bc7fb4a478817386a94&type=DASHBOARD_ACTION&name=UPDATE_PROFILE", ENDITEM, 
		"Url=Network01/content/themes/-2764790703747482922/image?_k=04186c5b68794be61ffa6bc7fb4a478817386a94&type=DASHBOARD_ACTION&name=CONTACTS", ENDITEM, 
		"Url=Network01/content/themes/-2764790703747482922/image?_k=04186c5b68794be61ffa6bc7fb4a478817386a94&type=DASHBOARD_ACTION&name=VIEW_MESSAGES", ENDITEM, 
		"Url=Network01/content/themes/-2764790703747482922/image?_k=04186c5b68794be61ffa6bc7fb4a478817386a94&type=DASHBOARD_ACTION&name=SEARCH_ADS", ENDITEM, 
		"Url=Network01/content/themes/-2764790703747482922/image?_k=04186c5b68794be61ffa6bc7fb4a478817386a94&type=DASHBOARD_ACTION&name=SEND_MESSAGE", ENDITEM, 
		"Url=Network01/content/themes/-2764790703747482922/image?_k=04186c5b68794be61ffa6bc7fb4a478817386a94&type=DASHBOARD_ACTION&name=PLACE_AD", ENDITEM, 
		"Url=Network01/content/themes/-2764790703747482922/image?_k=04186c5b68794be61ffa6bc7fb4a478817386a94&type=DASHBOARD_ACTION&name=VIEW_NOTIFICATIONS", ENDITEM, 
		"Url=Network01/content/themes/-2764790703747482922/image?_k=04186c5b68794be61ffa6bc7fb4a478817386a94&type=DASHBOARD_ACTION&name=DOCUMENTATION", ENDITEM, 
		"Url=Network01/content/themes/-2764790703747482922/image?_k=04186c5b68794be61ffa6bc7fb4a478817386a94&type=DASHBOARD_STATUS&name=ACCOUNT_BALANCE", ENDITEM, 
		"Url=Network01/content/themes/-2764790703747482922/image?_k=04186c5b68794be61ffa6bc7fb4a478817386a94&type=DASHBOARD_STATUS&name=MY_ADS", ENDITEM, 
		"Url=Network01/content/themes/-2764790703747482922/image?_k=04186c5b68794be61ffa6bc7fb4a478817386a94&type=DASHBOARD_STATUS&name=UNREAD_MESSAGES", ENDITEM, 
		"Url=Network01/content/themes/-2764790703747482922/image?_k=04186c5b68794be61ffa6bc7fb4a478817386a94&type=DASHBOARD_STATUS&name=LAST_LOGIN", ENDITEM, 
		*/LAST);

	
web_add_header("Origin","<p_ServerURL>");

	web_custom_request("initializationService", 
		"URL=<p_ServerURL>/cyclos/Network01/web-rpc/initializationService", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=<p_ServerURL>/cyclos/Network01", 
		"Snapshot=t5.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"operation\":\"getInitializationData\", \"params\":[null,null]}", 
		LAST);

	web_url("loadTranslations",
		"URL=<p_ServerURL>/cyclos/Network01/content/loadTranslations?_k=<c_KID>&cacheKey=<c_KID>&languageId=<languageId>&languageLastModified=&submodule=GENERAL.ERRORS&submodule=GENERAL.MENU&submodule=GENERAL.UI&submodule=ACCESS.LOGIN&submodule=MESSAGING.NOTIFICATIONS",
		"TargetFrame=",
		"Resource=0",
		"RecContentType=application/json",
		"Referer=<p_ServerURL>/cyclos/Network01",
		"Snapshot=t6.inf",
		"Mode=HTML",
		LAST);

web_add_header("Origin","<p_ServerURL>");

web_reg_find("Fail=NotFound","Search=Body","SaveCount=homepage_cnt","Text=Welcome to Network 01",LAST);
	
	web_custom_request("initializationService_2",
		"URL=<p_ServerURL>/cyclos/Network01/web-rpc/initializationService", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=<p_ServerURL>/cyclos/Network01", 
		"Snapshot=t7.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"operation\":\"getHomeData\", \"params\":[]}", 
		LAST);

	if(atoi(lr_eval_string("<homepage_cnt>"))>0)
	{
lr_end_transaction("BP02_01_OpenApplication",LR_PASS);
	}
	else
	{

lr_end_transaction("BP02_01_OpenApplication",LR_FAIL);
lr_output_message("Application Launch failed at =%s",lr_eval_string("<p_timestamp>"));
	}

lr_think_time(5);

web_reg_find("Fail=NotFound","Search=Body","SaveCount=loginpage_cnt","Text=System login",LAST);
	
lr_start_transaction("BP02_02_SignInPage");

	web_url("loadTranslations_2",
		"URL=<p_ServerURL>/cyclos/Network01/content/loadTranslations?_k=<c_KID>&cacheKey=<c_KID>&languageId=<languageId>&languageLastModified=&submodule=ACCESS.LOGIN",
		"TargetFrame=",
		"Resource=0",
		"RecContentType=application/json",
		"Referer=<p_ServerURL>/cyclos/Network01",
		"Snapshot=t8.inf",
		"Mode=HTML",
		LAST);

if(atoi(lr_eval_string("<loginpage_cnt>"))>0)
	{
lr_end_transaction("BP02_02_SignInPage",LR_PASS);
	}
	else
	{

lr_end_transaction("BP02_02_SignInPage",LR_FAIL);
lr_output_message("Signin page load failed at= %s",lr_eval_string("<p_timestamp>"));
	}
	
lr_think_time(5);

web_add_auto_header("Origin","<p_ServerURL>");

	web_reg_save_param_ex(
		"ParamName=c_sessionID",
		"LB=",
		"RB=",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=No",
		LAST);

lr_start_transaction("BP02_03_Login");

	web_submit_data("login",
		"Action=<p_ServerURL>/cyclos/Network01/content/login?_k=<c_KID>",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/plain",
		"Referer=<p_ServerURL>/cyclos/Network01",
		"Snapshot=t9.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=password", "Value=<p_password>", ENDITEM,
		"Name=principal", "Value=<p_username>", ENDITEM,
		"Name=principalType", "Value=username", ENDITEM,
		LAST);

web_add_header("Session-Prefix","<c_sessionID>");

/*Correlation comment: Automatic rules - Do not change!  
Original value='-2764790703479047466' 
Name ='userId' 
Type ='Rule' 
AppName ='AribaBuyer' 
RuleName ='c_userID1'*/
	web_reg_save_param_json(
		"ParamName=userId",
		"QueryString=$.result.userData.visibleAccounts[0].owner.id",
		SEARCH_FILTERS,
		"Scope=Body",
		LAST);

	web_custom_request("initializationService_3", 
		"URL=<p_ServerURL>/cyclos/Network01/web-rpc/initializationService", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=<p_ServerURL>/cyclos/Network01", 
		"Snapshot=t10.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"operation\":\"getInitializationData\", \"params\":[null,null]}", 
		LAST);

web_add_header("Session-Prefix","<c_sessionID>");

web_reg_find("Fail=NotFound","Search=Body","SaveCount=loginsuccess_cnt","Text=Network home page",LAST);

	web_custom_request("initializationService_4", 
		"URL=<p_ServerURL>/cyclos/Network01/web-rpc/initializationService", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=<p_ServerURL>/cyclos/Network01", 
		"Snapshot=t11.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"operation\":\"getHomeData\", \"params\":[]}", 
		LAST);

	if(atoi(lr_eval_string("<loginsuccess_cnt>"))>0)
	{
lr_end_transaction("BP02_03_Login",LR_PASS);
	}
	else
	{

lr_end_transaction("BP02_03_Login",LR_FAIL);
lr_output_message("Applicaion Login failed at = %s",lr_eval_string("<p_timestamp>"));
	}
lr_think_time(5);

	return 0;
}
