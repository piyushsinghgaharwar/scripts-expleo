Action()
{

	/* CLICK MARKETPLACE */

	lr_think_time(27);

	web_url("10.cache.js", 
		"URL=http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com/cyclos/Network01/cyclos.gwt/deferredjs/44283D0B5AB2110F2E0E4D288EF9A291/10.cache.js", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=text/javascript", 
		"Referer=http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com/cyclos/Network01", 
		"Snapshot=t12.inf", 
		LAST);

	web_url("4.cache.js", 
		"URL=http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com/cyclos/Network01/cyclos.gwt/deferredjs/44283D0B5AB2110F2E0E4D288EF9A291/4.cache.js", 
		"TargetFrame=", 
		"Resource=1", 
		"RecContentType=text/javascript", 
		"Referer=http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com/cyclos/Network01", 
		"Snapshot=t13.inf", 
		LAST);

	web_add_auto_header("Channel", 
		"main");

	web_add_auto_header("Session-Prefix", 
		"BNSohO27g3bNkd3b");

	web_url("loadTranslations_3", 
		"URL=http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com/cyclos/Network01/content/loadTranslations?_k=04186c5b68794be61ffa6bc7fb4a478817386a94&cacheKey=04186c5b68794be61ffa6bc7fb4a478817386a94&languageId=-2764790703814591786&languageLastModified=&submodule=MARKETPLACE.ADVERTISEMENTS&submodule=MARKETPLACE.CATEGORIES&submodule=MARKETPLACE.WEBSHOP_ORDERS&submodule=USERS.ADDRESSES&submodule=USERS.USERS", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com/cyclos/Network01", 
		"Snapshot=t14.inf", 
		"Mode=HTML", 
		LAST);

	web_add_header("Origin", 
		"http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com");

	web_custom_request("productsAndServices", 
		"URL=http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com/cyclos/Network01/web-rpc/productsAndServices", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com/cyclos/Network01", 
		"Snapshot=t15.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"operation\":\"getAdSearchData\", \"params\":[null,false]}", 
		EXTRARES, 
		"Url=../push-notifications?clientId=c5195b36-0505-44da-88e6-6611b39bb79b_1565723237216&eventTypes=loggedOut,newMessage,newNotification,deviceConfirmation&Session-Prefix=BNSohO27g3bNkd3b", "Referer=http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com/cyclos/Network01", ENDITEM, 
		LAST);

	/* CLICK MY ADVERTISEMENT */

	lr_think_time(4);

	web_url("loadTranslations_4", 
		"URL=http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com/cyclos/Network01/content/loadTranslations?_k=04186c5b68794be61ffa6bc7fb4a478817386a94&cacheKey=04186c5b68794be61ffa6bc7fb4a478817386a94&languageId=-2764790703814591786&languageLastModified=&submodule=MARKETPLACE.ADVERTISEMENTS", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com/cyclos/Network01", 
		"Snapshot=t16.inf", 
		"Mode=HTML", 
		LAST);

	web_add_auto_header("Origin", 
		"http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com");

	web_custom_request("productsAndServices_2", 
		"URL=http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com/cyclos/Network01/web-rpc/productsAndServices", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com/cyclos/Network01", 
		"Snapshot=t17.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"operation\":\"getUserAdsSearchData\", \"params\":[{\"class\":\"org.cyclos.model.users.users.UserLocatorVO\", \"id\":\"-2764790703479047466\"},\"ADVERTISEMENT\"]}", 
		LAST);

	web_custom_request("productsAndServices_3", 
		"URL=http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com/cyclos/Network01/web-rpc/productsAndServices", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com/cyclos/Network01", 
		"Snapshot=t18.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"operation\":\"search\", \"params\":[{\"class\":\"org.cyclos.model.marketplace.advertisements.BasicAdQuery\", \"owner\":{\"class\":\"org.cyclos.model.users.users.UserVO\", \"id\":\"-2764790703479047466\"}, \"type\":\"ADVERTISEMENT\", \"returnEditable\":true, \"hasImages\":false, \"currentPage\":0, \"pageSize\":40, \"orderBy\":\"RELEVANCE\"}]}", 
		EXTRARES, 
		"Url=../content/images/3z8VdzSwY0deyaxD74dkKhxftgAG7Cr4iS5ejucxElWpirws4FuJxl1zTUKHF6ug_625x245.png?_k=04186c5b68794be61ffa6bc7fb4a478817386a94&width=150&height=150", "Referer=http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com/cyclos/Network01", ENDITEM, 
		"Url=../content/images/2yJnRQrbqynhFr574TkArSXAsXkygazuf1lB2dsHWOvQtxWhhv6T6DkVCVeZWXGf_625x245.png?_k=04186c5b68794be61ffa6bc7fb4a478817386a94&width=150&height=150", "Referer=http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com/cyclos/Network01", ENDITEM, 
		"Url=../content/images/2YtcaBA57dbdBqdbn30Ep83pwYf0AQl4WDHgawFJu9wbSpb49UdDieQXUEFRLAZ8_625x245.png?_k=04186c5b68794be61ffa6bc7fb4a478817386a94&width=150&height=150", "Referer=http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com/cyclos/Network01", ENDITEM, 
		"Url=../content/images/x97Joy1AzwhQRJehPyqRXGvsVP854cjw0qVMk0XcLCkpAAdTXGtPt4txz11aDDTN_625x245.png?_k=04186c5b68794be61ffa6bc7fb4a478817386a94&width=150&height=150", "Referer=http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com/cyclos/Network01", ENDITEM, 
		LAST);

	/* CLICK NEW */

	web_revert_auto_header("Origin");

	web_url("loadTranslations_5", 
		"URL=http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com/cyclos/Network01/content/loadTranslations?_k=04186c5b68794be61ffa6bc7fb4a478817386a94&cacheKey=04186c5b68794be61ffa6bc7fb4a478817386a94&languageId=-2764790703814591786&languageLastModified=&submodule=MARKETPLACE.ADVERTISEMENTS&submodule=SYSTEM.ENTITY_LOGS&submodule=USERS.ADDRESSES", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com/cyclos/Network01", 
		"Snapshot=t19.inf", 
		"Mode=HTML", 
		LAST);

	web_add_header("Origin", 
		"http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com");

	web_custom_request("productsAndServices_4", 
		"URL=http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com/cyclos/Network01/web-rpc/productsAndServices", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com/cyclos/Network01", 
		"Snapshot=t20.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"operation\":\"getDataForNew\", \"params\":[{\"class\":\"org.cyclos.model.marketplace.advertisements.AdDataParams\", \"type\":\"ADVERTISEMENT\", \"user\":{\"class\":\"org.cyclos.model.users.users.UserLocatorVO\", \"id\":\"-2764790703479047466\"}, \"basedOnId\":null}]}", 
		EXTRARES, 
		"Url=../content/themes/-2764790703747482922/image?_k=04186c5b68794be61ffa6bc7fb4a478817386a94&type=TOOLBAR_ICON&name=FONT", "Referer=http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com/cyclos/Network01", ENDITEM, 
		"Url=../content/themes/-2764790703747482922/image?_k=04186c5b68794be61ffa6bc7fb4a478817386a94&type=TOOLBAR_ICON&name=INCREASE_SIZE", "Referer=http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com/cyclos/Network01", ENDITEM, 
		"Url=../content/themes/-2764790703747482922/image?_k=04186c5b68794be61ffa6bc7fb4a478817386a94&type=TOOLBAR_ICON&name=DECREASE_SIZE", "Referer=http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com/cyclos/Network01", ENDITEM, 
		"Url=../content/themes/-2764790703747482922/image?_k=04186c5b68794be61ffa6bc7fb4a478817386a94&type=TOOLBAR_ICON&name=FOREGROUND_COLOR", "Referer=http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com/cyclos/Network01", ENDITEM, 
		"Url=../content/themes/-2764790703747482922/image?_k=04186c5b68794be61ffa6bc7fb4a478817386a94&type=TOOLBAR_ICON&name=BACKGROUND_COLOR", "Referer=http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com/cyclos/Network01", ENDITEM, 
		"Url=../content/themes/-2764790703747482922.css?version=4.12", "Referer=", ENDITEM, 
		"Url=../content/themes/-2764790703747482922/image?_k=04186c5b68794be61ffa6bc7fb4a478817386a94&type=TOOLBAR_ICON&name=BOLD", "Referer=http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com/cyclos/Network01", ENDITEM, 
		"Url=../content/themes/-2764790703747482922/image?_k=04186c5b68794be61ffa6bc7fb4a478817386a94&type=TOOLBAR_ICON&name=ITALIC", "Referer=http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com/cyclos/Network01", ENDITEM, 
		"Url=../content/themes/-2764790703747482922/image?_k=04186c5b68794be61ffa6bc7fb4a478817386a94&type=TOOLBAR_ICON&name=UNDERLINE", "Referer=http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com/cyclos/Network01", ENDITEM, 
		"Url=../content/themes/-2764790703747482922/image?_k=04186c5b68794be61ffa6bc7fb4a478817386a94&type=TOOLBAR_ICON&name=STRIKE_THROUGH", "Referer=http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com/cyclos/Network01", ENDITEM, 
		"Url=../content/themes/-2764790703747482922/image?_k=04186c5b68794be61ffa6bc7fb4a478817386a94&type=TOOLBAR_ICON&name=REMOVE_LINK", "Referer=http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com/cyclos/Network01", ENDITEM, 
		"Url=../content/themes/-2764790703747482922/image?_k=04186c5b68794be61ffa6bc7fb4a478817386a94&type=TOOLBAR_ICON&name=EDIT_HTML", "Referer=http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com/cyclos/Network01", ENDITEM, 
		"Url=../content/themes/-2764790703747482922/image?_k=04186c5b68794be61ffa6bc7fb4a478817386a94&type=TOOLBAR_ICON&name=JUSTIFY_LEFT", "Referer=http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com/cyclos/Network01", ENDITEM, 
		"Url=../content/themes/-2764790703747482922/image?_k=04186c5b68794be61ffa6bc7fb4a478817386a94&type=TOOLBAR_ICON&name=INDENT", "Referer=http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com/cyclos/Network01", ENDITEM, 
		"Url=../content/themes/-2764790703747482922/image?_k=04186c5b68794be61ffa6bc7fb4a478817386a94&type=TOOLBAR_ICON&name=REMOVE_FORMAT", "Referer=http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com/cyclos/Network01", ENDITEM, 
		"Url=../content/themes/-2764790703747482922/image?_k=04186c5b68794be61ffa6bc7fb4a478817386a94&type=TOOLBAR_ICON&name=JUSTIFY_CENTER", "Referer=http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com/cyclos/Network01", ENDITEM, 
		"Url=../content/themes/-2764790703747482922/image?_k=04186c5b68794be61ffa6bc7fb4a478817386a94&type=TOOLBAR_ICON&name=OUTDENT", "Referer=http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com/cyclos/Network01", ENDITEM, 
		"Url=../content/themes/-2764790703747482922/image?_k=04186c5b68794be61ffa6bc7fb4a478817386a94&type=TOOLBAR_ICON&name=JUSTIFY_RIGHT", "Referer=http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com/cyclos/Network01", ENDITEM, 
		"Url=../content/themes/-2764790703747482922/image?_k=04186c5b68794be61ffa6bc7fb4a478817386a94&type=TOOLBAR_ICON&name=ORDERED_LIST", "Referer=http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com/cyclos/Network01", ENDITEM, 
		"Url=../content/themes/-2764790703747482922/image?_k=04186c5b68794be61ffa6bc7fb4a478817386a94&type=TOOLBAR_ICON&name=CREATE_LINK", "Referer=http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com/cyclos/Network01", ENDITEM, 
		"Url=../content/themes/-2764790703747482922/image?_k=04186c5b68794be61ffa6bc7fb4a478817386a94&type=TOOLBAR_ICON&name=UNORDERED_LIST", "Referer=http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com/cyclos/Network01", ENDITEM, 
		"Url=../push-notifications?clientId=c5195b36-0505-44da-88e6-6611b39bb79b_1565723237216&eventTypes=loggedOut,newMessage,newNotification,deviceConfirmation&Session-Prefix=BNSohO27g3bNkd3b", "Referer=http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com/cyclos/Network01", ENDITEM, 
		LAST);

	/* CLICK SELECT AN OPTION */

	/* ENTER PRICE */

	web_revert_auto_header("Channel");

	web_revert_auto_header("Session-Prefix");

	web_add_header("Sec-Fetch-Site", 
		"none");

	lr_think_time(30);

	web_url("plugins_win.json", 
		"URL=https://www.gstatic.com/chrome/config/plugins_3/plugins_win.json", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t21.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com/cyclos/Network01/push-notifications?clientId=c5195b36-0505-44da-88e6-6611b39bb79b_1565723237216&eventTypes=loggedOut,newMessage,newNotification,deviceConfirmation&Session-Prefix=BNSohO27g3bNkd3b", "Referer=http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com/cyclos/Network01", ENDITEM, 
		LAST);

	/* CLICK ADD AN IMAGE */

	web_add_auto_header("Channel", 
		"main");

	web_add_auto_header("Origin", 
		"http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com");

	web_add_auto_header("Session-Prefix", 
		"BNSohO27g3bNkd3b");

	lr_think_time(15);

	web_submit_data("temp", 
		"Action=http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com/cyclos/Network01/content/images/temp?_k=04186c5b68794be61ffa6bc7fb4a478817386a94", 
		"Method=POST", 
		"EncType=multipart/form-data", 
		"TargetFrame=", 
		"RecContentType=application/json", 
		"Referer=http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com/cyclos/Network01", 
		"Snapshot=t22.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=target", "Value=ADVERTISEMENT", ENDITEM, 
		"Name=guestKey", "Value=uZqcumVeyMwyARwlhDbh9aPDKtDKSMgSrVccuidZ0ym0Yv8KarHiZr02kAYYaIZX", ENDITEM, 
		"Name=userId", "Value=-2764790703479047466", ENDITEM, 
		"Name=file", "Value=property1.jpg", "File=Yes", ENDITEM, 
		EXTRARES, 
		"Url=VmkPuZMSrbQlKv3Vx60kTzNRDtW0dwJnX1tKVFDUBloH1QVLarncKFh6ErHY8QOR_476x317.jpeg?_k=04186c5b68794be61ffa6bc7fb4a478817386a94&width=150&height=150", "Referer=http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com/cyclos/Network01", ENDITEM, 
		LAST);

	/* SAVE IMAGE AND AD */

	lr_think_time(12);

	web_custom_request("productsAndServices_5", 
		"URL=http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com/cyclos/Network01/web-rpc/productsAndServices", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com/cyclos/Network01", 
		"Snapshot=t23.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"operation\":\"save\", \"params\":[{\"class\":\"org.cyclos.model.marketplace.advertisements.AdvertisementDTO\", \"owner\":{\"class\":\"org.cyclos.model.users.users.UserVO\", \"display\":\"PerfTestUser4\", \"shortDisplay\":\"PerfTestUser4\", \"id\":\"-2764790703479047466\"}, \"categories\":[{\"class\":\"org.cyclos.model.marketplace.categories.AdCategoryDetailedVO\", \"active\":true, \"images\":[], \"childrenCount\":0, \"id\":\"-2764790703646819626\", \"name\":\"Property\"}], \"addresses\":[]"
		", \"customValues\":[], \"publicationPeriod\":{\"class\":\"org.cyclos.model.utils.DatePeriodDTO\", \"end\":\"2019-11-13T22:59:59.999Z\", \"begin\":\"2019-08-13T00:00:00.000+01:00\"}, \"promotionalPeriodActive\":false, \"uploadedImages\":[{\"class\":\"org.cyclos.model.system.images.ImageVO\", \"key\":\"VmkPuZMSrbQlKv3Vx60kTzNRDtW0dwJnX1tKVFDUBloH1QVLarncKFh6ErHY8QOR_476x317.jpeg\", \"nature\":\"TEMP\", \"width\":476, \"height\":317, \"convertedToJpeg\":false, \"contentType\":\"image/jpeg\", \""
		"length\":23973, \"name\":\"property1\", \"id\":\"-2764790696097072426\", \"lastModified\":\"2019-08-13T20:10:34.421+01:00\", \"lastModifiedInMillis\":\"1565723434421\"}], \"status\":\"ACTIVE\", \"price\":{\"class\":\"org.cyclos.model.utils.CurrencyAmountDTO\", \"amount\":\"20.00\", \"currency\":{\"class\":\"org.cyclos.model.banking.currencies.CurrencyVO\", \"symbol\":\"U\", \"precision\":2, \"global\":false, \"prefix\":\"U \", \"internalName\":\"unit\", \"id\":\"-2764790703747482922\", \"name\":\""
		"Units\"}}, \"name\":\"TEST TITLE 44\", \"description\":\"THIS IS TEST DESCRIPTION\"}]}", 
		LAST);

	web_custom_request("productsAndServices_6", 
		"URL=http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com/cyclos/Network01/web-rpc/productsAndServices", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com/cyclos/Network01", 
		"Snapshot=t24.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"operation\":\"getData\", \"params\":[\"-2764790699385406762\"]}", 
		EXTRARES, 
		"Url=../push-notifications?clientId=c5195b36-0505-44da-88e6-6611b39bb79b_1565723237216&eventTypes=loggedOut,newMessage,newNotification,deviceConfirmation&Session-Prefix=BNSohO27g3bNkd3b", "Referer=http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com/cyclos/Network01", ENDITEM, 
		LAST);

	/* CLICK ON MARKETPLACE */

	web_custom_request("productsAndServices_7", 
		"URL=http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com/cyclos/Network01/web-rpc/productsAndServices", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com/cyclos/Network01", 
		"Snapshot=t25.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"operation\":\"getAdSearchData\", \"params\":[null,false]}", 
		LAST);

	/* ENTER TITLE AND CLICK ON LIST AD */

	lr_think_time(37);

	web_custom_request("productsAndServices_8", 
		"URL=http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com/cyclos/Network01/web-rpc/productsAndServices", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com/cyclos/Network01", 
		"Snapshot=t26.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"operation\":\"search\", \"params\":[{\"class\":\"org.cyclos.model.marketplace.advertisements.BasicAdQuery\", \"type\":\"ADVERTISEMENT\", \"groups\":[], \"orderBy\":\"DATE\", \"returnEditable\":false, \"hasImages\":false, \"currentPage\":0, \"pageSize\":40, \"state\":\"INITIAL\", \"userProfileFields\":[], \"adCustomValues\":[], \"priceRange\":null, \"keywords\":\"TEST TITLE 44\", \"addressResult\":\"NO_ADDRESSES\"}]}", 
		EXTRARES, 
		"Url=../push-notifications?clientId=c5195b36-0505-44da-88e6-6611b39bb79b_1565723237216&eventTypes=loggedOut,newMessage,newNotification,deviceConfirmation&Session-Prefix=BNSohO27g3bNkd3b", "Referer=http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com/cyclos/Network01", ENDITEM, 
		LAST);

	web_custom_request("productsAndServices_9", 
		"URL=http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com/cyclos/Network01/web-rpc/productsAndServices", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com/cyclos/Network01", 
		"Snapshot=t27.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"operation\":\"search\", \"params\":[{\"class\":\"org.cyclos.model.marketplace.advertisements.BasicAdQuery\", \"type\":\"ADVERTISEMENT\", \"groups\":[], \"orderBy\":\"DATE\", \"returnEditable\":false, \"hasImages\":false, \"currentPage\":0, \"pageSize\":40, \"state\":\"INITIAL\", \"userProfileFields\":[], \"adCustomValues\":[], \"priceRange\":null, \"keywords\":\"TEST TITLE 4\", \"addressResult\":\"NO_ADDRESSES\"}]}", 
		LAST);

	/* SELECT AD */

	web_revert_auto_header("Origin");

	lr_think_time(20);

	web_url("loadTranslations_6", 
		"URL=http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com/cyclos/Network01/content/loadTranslations?_k=04186c5b68794be61ffa6bc7fb4a478817386a94&cacheKey=04186c5b68794be61ffa6bc7fb4a478817386a94&languageId=-2764790703814591786&languageLastModified=&submodule=MARKETPLACE.ADVERTISEMENTS&submodule=MARKETPLACE.WEBSHOP_ORDERS&submodule=MARKETPLACE.WEBSHOP_DELIVERY_METHODS&submodule=USERS.ADDRESSES&submodule=MESSAGING.MESSAGES", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com/cyclos/Network01", 
		"Snapshot=t28.inf", 
		"Mode=HTML", 
		LAST);

	web_add_auto_header("Origin", 
		"http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com");

	web_custom_request("productsAndServices_10", 
		"URL=http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com/cyclos/Network01/web-rpc/productsAndServices", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com/cyclos/Network01", 
		"Snapshot=t29.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"operation\":\"getViewData\", \"params\":[{\"class\":\"org.cyclos.model.marketplace.advertisements.BasicAdVO\", \"id\":\"-2764790699385406762\"}]}", 
		EXTRARES, 
		"Url=../content/images/VmkPuZMSrbQlKv3Vx60kTzNRDtW0dwJnX1tKVFDUBloH1QVLarncKFh6ErHY8QOR_476x317.jpeg?_k=04186c5b68794be61ffa6bc7fb4a478817386a94&width=240&height=240", "Referer=http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com/cyclos/Network01", ENDITEM, 
		LAST);

	/* LOGOUT */

	lr_think_time(18);

	web_custom_request("loginService", 
		"URL=http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com/cyclos/Network01/web-rpc/loginService", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com/cyclos/Network01", 
		"Snapshot=t30.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"operation\":\"logout\", \"params\":[]}", 
		LAST);

	web_revert_auto_header("Session-Prefix");

	web_custom_request("initializationService_5", 
		"URL=http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com/cyclos/Network01/web-rpc/initializationService", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com/cyclos/Network01", 
		"Snapshot=t31.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"operation\":\"getInitializationData\", \"params\":[null,null]}", 
		LAST);

	web_custom_request("initializationService_6", 
		"URL=http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com/cyclos/Network01/web-rpc/initializationService", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com/cyclos/Network01", 
		"Snapshot=t32.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"operation\":\"getHomeData\", \"params\":[]}", 
		LAST);

	return 0;
}