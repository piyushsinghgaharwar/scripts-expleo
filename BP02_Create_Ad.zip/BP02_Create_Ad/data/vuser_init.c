/* -------------------------------------------------------------------------------
	Script Title       : 
	Script Description : 
                        
                        
	Recorder Version   : 971
   ------------------------------------------------------------------------------- */

vuser_init()
{

	web_set_sockets_option("SSL_VERSION", "TLS1.2");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_url("Network01", 
		"URL=http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com/cyclos/Network01", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=Network01/js/load-image.all.min.js?_k=04186c5b68794be61ffa6bc7fb4a478817386a94", ENDITEM, 
		"Url=Network01/js/script.min.js?_k=04186c5b68794be61ffa6bc7fb4a478817386a94", ENDITEM, 
		"Url=Network01/cyclos.gwt/cyclos.gwt.nocache.js?_k=04186c5b68794be61ffa6bc7fb4a478817386a94", ENDITEM, 
		"Url=Network01/cyclos.gwt/44283D0B5AB2110F2E0E4D288EF9A291.cache.js", ENDITEM, 
		"Url=Network01/content/themes/-2764790703747482922.css?_k=04186c5b68794be61ffa6bc7fb4a478817386a94&lastModified=1562772279057", ENDITEM, 
		"Url=Network01/cyclos.gwt/clear.cache.gif", ENDITEM, 
		"Url=Network01/content/images/currentConfiguration/SYSTEM_LOGO?mod=1564996692527", ENDITEM, 
		"Url=Network01/push-notifications?clientId=c5195b36-0505-44da-88e6-6611b39bb79b_1565723237216&eventTypes=loggedOut,newMessage,newNotification,deviceConfirmation&Session-Prefix=BNSohO27g3bNkd3b", ENDITEM, 
		"Url=Network01/content/themes/-2764790703747482922/image?_k=04186c5b68794be61ffa6bc7fb4a478817386a94&type=DASHBOARD_ACTION&name=ACCOUNT_INFO", ENDITEM, 
		"Url=Network01/content/themes/-2764790703747482922/image?_k=04186c5b68794be61ffa6bc7fb4a478817386a94&type=DASHBOARD_ACTION&name=PAYMENT_USER_TO_USER", ENDITEM, 
		"Url=Network01/content/themes/-2764790703747482922/image?_k=04186c5b68794be61ffa6bc7fb4a478817386a94&type=DASHBOARD_ACTION&name=PAYMENT_USER_TO_SYSTEM", ENDITEM, 
		"Url=Network01/content/themes/-2764790703747482922/image?_k=04186c5b68794be61ffa6bc7fb4a478817386a94&type=DASHBOARD_ACTION&name=SEARCH_USERS", ENDITEM, 
		"Url=Network01/content/themes/-2764790703747482922/image?_k=04186c5b68794be61ffa6bc7fb4a478817386a94&type=DASHBOARD_ACTION&name=UPDATE_PROFILE", ENDITEM, 
		"Url=Network01/content/themes/-2764790703747482922/image?_k=04186c5b68794be61ffa6bc7fb4a478817386a94&type=DASHBOARD_ACTION&name=CONTACTS", ENDITEM, 
		"Url=Network01/content/themes/-2764790703747482922/image?_k=04186c5b68794be61ffa6bc7fb4a478817386a94&type=DASHBOARD_ACTION&name=VIEW_MESSAGES", ENDITEM, 
		"Url=Network01/content/themes/-2764790703747482922/image?_k=04186c5b68794be61ffa6bc7fb4a478817386a94&type=DASHBOARD_ACTION&name=SEARCH_ADS", ENDITEM, 
		"Url=Network01/content/themes/-2764790703747482922/image?_k=04186c5b68794be61ffa6bc7fb4a478817386a94&type=DASHBOARD_ACTION&name=SEND_MESSAGE", ENDITEM, 
		"Url=Network01/content/themes/-2764790703747482922/image?_k=04186c5b68794be61ffa6bc7fb4a478817386a94&type=DASHBOARD_ACTION&name=PLACE_AD", ENDITEM, 
		"Url=Network01/content/themes/-2764790703747482922/image?_k=04186c5b68794be61ffa6bc7fb4a478817386a94&type=DASHBOARD_ACTION&name=VIEW_NOTIFICATIONS", ENDITEM, 
		"Url=Network01/content/themes/-2764790703747482922/image?_k=04186c5b68794be61ffa6bc7fb4a478817386a94&type=DASHBOARD_ACTION&name=DOCUMENTATION", ENDITEM, 
		"Url=Network01/content/themes/-2764790703747482922/image?_k=04186c5b68794be61ffa6bc7fb4a478817386a94&type=DASHBOARD_STATUS&name=ACCOUNT_BALANCE", ENDITEM, 
		"Url=Network01/content/themes/-2764790703747482922/image?_k=04186c5b68794be61ffa6bc7fb4a478817386a94&type=DASHBOARD_STATUS&name=MY_ADS", ENDITEM, 
		"Url=Network01/content/themes/-2764790703747482922/image?_k=04186c5b68794be61ffa6bc7fb4a478817386a94&type=DASHBOARD_STATUS&name=UNREAD_MESSAGES", ENDITEM, 
		"Url=Network01/content/themes/-2764790703747482922/image?_k=04186c5b68794be61ffa6bc7fb4a478817386a94&type=DASHBOARD_STATUS&name=LAST_LOGIN", ENDITEM, 
		LAST);

	web_add_auto_header("Sec-Fetch-Mode", 
		"cors");

	web_add_auto_header("Sec-Fetch-Site", 
		"cross-site");

	web_url("track", 
		"URL=https://api.mixpanel.com/track/?data="
		"eyJldmVudCI6ICJtcF9wYWdlX3ZpZXciLCJwcm9wZXJ0aWVzIjogeyIkb3MiOiAiV2luZG93cyIsIiRicm93c2VyIjogIkNocm9tZSIsIiRjdXJyZW50X3VybCI6ICJjaHJvbWUtZXh0ZW5zaW9uOi8vbWJvcGdtZG5wY2JvaGhwbmZnbGdvaGxiaGZvbmdhYmkvX2dlbmVyYXRlZF9iYWNrZ3JvdW5kX3BhZ2UuaHRtbCIsIiRicm93c2VyX3ZlcnNpb24iOiA3NiwiJHNjcmVlbl9oZWlnaHQiOiA3NjgsIiRzY3JlZW5fd2lkdGgiOiAxMzY2LCJtcF9saWIiOiAid2ViIiwiJGxpYl92ZXJzaW9uIjogIjIuMjkuMCIsInRpbWUiOiAxNTY1NzIzMjMyLjg4MywiZGlzdGluY3RfaWQiOiA2OTUzNzgsIiRkZXZpY2VfaWQiOiAiMTZjODIzZTI4NjI2YzctMDA1NTYyNjM5ZmM3ZD"
		"UtNzM3M2U2MS0xMDAyMDAtMTZjODIzZTI4NjM3NjMiLCIkaW5pdGlhbF9yZWZlcnJlciI6ICIkZGlyZWN0IiwiJGluaXRpYWxfcmVmZXJyaW5nX2RvbWFpbiI6ICIkZGlyZWN0IiwiJHVzZXJfaWQiOiA2OTUzNzgsIm1wX3BhZ2UiOiAiY2hyb21lLWV4dGVuc2lvbjovL21ib3BnbWRucGNib2hocG5mZ2xnb2hsYmhmb25nYWJpL19nZW5lcmF0ZWRfYmFja2dyb3VuZF9wYWdlLmh0bWwiLCJtcF9icm93c2VyIjogIkNocm9tZSIsIm1wX3BsYXRmb3JtIjogIldpbmRvd3MiLCJ0b2tlbiI6ICI5NGI1YzMxMTY5MmU3YzlkMDNjZWY5YzlhN2EzMmVhZiJ9fQ%3D%3D&ip=1&_=1565723232884", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t2.inf", 
		"Mode=HTML", 
		LAST);

	web_url("decide", 
		"URL=https://api.mixpanel.com/decide/?verbose=1&version=1&lib=web&token=94b5c311692e7c9d03cef9c9a7a32eaf&ip=1&_=1565723232878", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		LAST);

	web_url("track_2", 
		"URL=https://api.mixpanel.com/track/?data="
		"eyJldmVudCI6ICIkd2ViX2V2ZW50IiwicHJvcGVydGllcyI6IHsiJG9zIjogIldpbmRvd3MiLCIkYnJvd3NlciI6ICJDaHJvbWUiLCIkY3VycmVudF91cmwiOiAiY2hyb21lLWV4dGVuc2lvbjovL21ib3BnbWRucGNib2hocG5mZ2xnb2hsYmhmb25nYWJpL19nZW5lcmF0ZWRfYmFja2dyb3VuZF9wYWdlLmh0bWwiLCIkYnJvd3Nlcl92ZXJzaW9uIjogNzYsIiRzY3JlZW5faGVpZ2h0IjogNzY4LCIkc2NyZWVuX3dpZHRoIjogMTM2NiwibXBfbGliIjogIndlYiIsIiRsaWJfdmVyc2lvbiI6ICIyLjI5LjAiLCJ0aW1lIjogMTU2NTcyMzIzNy4xMDcsImRpc3RpbmN0X2lkIjogNjk1Mzc4LCIkZGV2aWNlX2lkIjogIjE2YzgyM2UyODYyNmM3LTAwNTU2MjYzOWZjN2Q1LT"
		"czNzNlNjEtMTAwMjAwLTE2YzgyM2UyODYzNzYzIiwiJGluaXRpYWxfcmVmZXJyZXIiOiAiJGRpcmVjdCIsIiRpbml0aWFsX3JlZmVycmluZ19kb21haW4iOiAiJGRpcmVjdCIsIiR1c2VyX2lkIjogNjk1Mzc4LCIkdGl0bGUiOiAiIiwiJGV2ZW50X3R5cGUiOiAicGFnZXZpZXciLCIkY2VfdmVyc2lvbiI6IDEsIiRob3N0IjogIm1ib3BnbWRucGNib2hocG5mZ2xnb2hsYmhmb25nYWJpIiwiJHBhdGhuYW1lIjogIi9fZ2VuZXJhdGVkX2JhY2tncm91bmRfcGFnZS5odG1sIiwidG9rZW4iOiAiOTRiNWMzMTE2OTJlN2M5ZDAzY2VmOWM5YTdhMzJlYWYifX0%3D&ip=1&_=1565723237108", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		LAST);

	web_revert_auto_header("Sec-Fetch-Mode");

	web_revert_auto_header("Sec-Fetch-Site");

	web_add_auto_header("Channel", 
		"main");

	web_add_header("Origin", 
		"http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com");

	web_custom_request("initializationService", 
		"URL=http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com/cyclos/Network01/web-rpc/initializationService", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com/cyclos/Network01", 
		"Snapshot=t5.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"operation\":\"getInitializationData\", \"params\":[null,null]}", 
		LAST);

	web_url("loadTranslations", 
		"URL=http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com/cyclos/Network01/content/loadTranslations?_k=04186c5b68794be61ffa6bc7fb4a478817386a94&cacheKey=04186c5b68794be61ffa6bc7fb4a478817386a94&languageId=-2764790703814591786&languageLastModified=&submodule=GENERAL.ERRORS&submodule=GENERAL.MENU&submodule=GENERAL.UI&submodule=ACCESS.LOGIN&submodule=MESSAGING.NOTIFICATIONS", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com/cyclos/Network01", 
		"Snapshot=t6.inf", 
		"Mode=HTML", 
		LAST);

	web_add_header("Origin", 
		"http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com");

	web_custom_request("initializationService_2", 
		"URL=http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com/cyclos/Network01/web-rpc/initializationService", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com/cyclos/Network01", 
		"Snapshot=t7.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"operation\":\"getHomeData\", \"params\":[]}", 
		LAST);

	/* Application Launched */

	/* CLICK ON SIGNIN */

	lr_think_time(19);

	web_url("loadTranslations_2", 
		"URL=http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com/cyclos/Network01/content/loadTranslations?_k=04186c5b68794be61ffa6bc7fb4a478817386a94&cacheKey=04186c5b68794be61ffa6bc7fb4a478817386a94&languageId=-2764790703814591786&languageLastModified=&submodule=ACCESS.LOGIN", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com/cyclos/Network01", 
		"Snapshot=t8.inf", 
		"Mode=HTML", 
		LAST);

	/* CLICK LOGIN BUTTON */

	web_add_auto_header("Origin", 
		"http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com");

	lr_think_time(23);

	web_submit_data("login", 
		"Action=http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com/cyclos/Network01/content/login?_k=04186c5b68794be61ffa6bc7fb4a478817386a94", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/plain", 
		"Referer=http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com/cyclos/Network01", 
		"Snapshot=t9.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=password", "Value=password123", ENDITEM, 
		"Name=principal", "Value=PerfTestUser4", ENDITEM, 
		"Name=principalType", "Value=username", ENDITEM, 
		LAST);

	web_add_auto_header("Session-Prefix", 
		"BNSohO27g3bNkd3b");

	web_custom_request("initializationService_3", 
		"URL=http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com/cyclos/Network01/web-rpc/initializationService", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com/cyclos/Network01", 
		"Snapshot=t10.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"operation\":\"getInitializationData\", \"params\":[null,null]}", 
		LAST);

	web_custom_request("initializationService_4", 
		"URL=http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com/cyclos/Network01/web-rpc/initializationService", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com/cyclos/Network01", 
		"Snapshot=t11.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"operation\":\"getHomeData\", \"params\":[]}", 
		LAST);

	return 0;
}
