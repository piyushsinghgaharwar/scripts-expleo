Action()
{

	
web_add_header("Session-Prefix","<c_sessionID>");

web_reg_find("Fail=NotFound","Search=Body","SaveCount=mrktplc_cnt","Text=Search advertisements",LAST);

lr_start_transaction("BP02_04_MarketPlace");

	web_url("loadTranslations_3",
		"URL=<p_ServerURL>/cyclos/Network01/content/loadTranslations?_k=<c_KID>&cacheKey=<c_KID>&languageId=<languageId>&languageLastModified=&submodule=MARKETPLACE.ADVERTISEMENTS&submodule=MARKETPLACE.CATEGORIES&submodule=MARKETPLACE.WEBSHOP_ORDERS&submodule=USERS.ADDRESSES&submodule=USERS.USERS",
		"TargetFrame=",
		"Resource=0",
		"RecContentType=application/json",
		"Referer=<p_ServerURL>/cyclos/Network01",
		"Snapshot=t14.inf",
		"Mode=HTML",
		LAST);

web_add_header("Origin","<p_ServerURL>");
web_add_header("Session-Prefix","<c_sessionID>");

	web_custom_request("productsAndServices", 
		"URL=<p_ServerURL>/cyclos/Network01/web-rpc/productsAndServices", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=<p_ServerURL>/cyclos/Network01", 
		"Snapshot=t15.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"operation\":\"getAdSearchData\", \"params\":[null,false]}", 
		EXTRARES, 
		//"Url=../push-notifications?clientId=c5195b36-0505-44da-88e6-6611b39bb79b_1565723237216&eventTypes=loggedOut,newMessage,newNotification,deviceConfirmation&Session-Prefix=<c_sessionID>", "Referer=<p_ServerURL>/cyclos/Network01", ENDITEM, 
		LAST);

if(atoi(lr_eval_string("<mrktplc_cnt>"))>0)
	{
lr_end_transaction("BP02_04_MarketPlace",LR_PASS);
	}
	else
	{

lr_end_transaction("BP02_04_MarketPlace",LR_FAIL);
lr_output_message("Marketplace page load failed at = %s",lr_eval_string("<p_timestamp>"));
	}
	
lr_think_time(5);

web_add_header("Session-Prefix","<c_sessionID>");

web_reg_find("Fail=NotFound","Search=Body","SaveCount=myadv_cnt","Text=My advertisements",LAST);

lr_start_transaction("BP02_05_MyAdvertisement");

	web_url("loadTranslations_4",
		"URL=<p_ServerURL>/cyclos/Network01/content/loadTranslations?_k=<c_KID>&cacheKey=<c_KID>&languageId=<languageId>&languageLastModified=&submodule=MARKETPLACE.ADVERTISEMENTS",
		"TargetFrame=",
		"Resource=0",
		"RecContentType=application/json",
		"Referer=<p_ServerURL>/cyclos/Network01",
		"Snapshot=t16.inf",
		"Mode=HTML",
		LAST);

web_add_auto_header("Origin","<p_ServerURL>");
	
web_add_header("Session-Prefix","<c_sessionID>");

	web_custom_request("productsAndServices_2",
		"URL=<p_ServerURL>/cyclos/Network01/web-rpc/productsAndServices",
		"Method=POST",
		"TargetFrame=",
		"Resource=0",
		"RecContentType=application/json",
		"Referer=<p_ServerURL>/cyclos/Network01",
		"Snapshot=t17.inf",
		"Mode=HTML",
		"EncType=application/json",
		"Body={\"operation\":\"getUserAdsSearchData\", \"params\":[{\"class\":\"org.cyclos.model.users.users.UserLocatorVO\", \"id\":\"<userId>\"},\"ADVERTISEMENT\"]}",
		LAST);

	web_custom_request("productsAndServices_3",
		"URL=<p_ServerURL>/cyclos/Network01/web-rpc/productsAndServices",
		"Method=POST",
		"TargetFrame=",
		"Resource=0",
		"RecContentType=application/json",
		"Referer=<p_ServerURL>/cyclos/Network01",
		"Snapshot=t18.inf",
		"Mode=HTML",
		"EncType=application/json",
		"Body={\"operation\":\"search\", \"params\":[{\"class\":\"org.cyclos.model.marketplace.advertisements.BasicAdQuery\", \"owner\":{\"class\":\"org.cyclos.model.users.users.UserVO\", \"id\":\"<userId>\"}, \"type\":\"ADVERTISEMENT\", \"returnEditable\":true, \"hasImages\":false, \"currentPage\":0, \"pageSize\":40, \"orderBy\":\"RELEVANCE\"}]}",
		EXTRARES,
		/*"URL=../content/images/3z8VdzSwY0deyaxD74dkKhxftgAG7Cr4iS5ejucxElWpirws4FuJxl1zTUKHF6ug_625x245.png?_k=04186c5b68794be61ffa6bc7fb4a478817386a94&width=150&height=150", "Referer=<p_ServerURL>/cyclos/Network01", ENDITEM,
		"URL=../content/images/2yJnRQrbqynhFr574TkArSXAsXkygazuf1lB2dsHWOvQtxWhhv6T6DkVCVeZWXGf_625x245.png?_k=04186c5b68794be61ffa6bc7fb4a478817386a94&width=150&height=150", "Referer=<p_ServerURL>/cyclos/Network01", ENDITEM,
		"URL=../content/images/2YtcaBA57dbdBqdbn30Ep83pwYf0AQl4WDHgawFJu9wbSpb49UdDieQXUEFRLAZ8_625x245.png?_k=04186c5b68794be61ffa6bc7fb4a478817386a94&width=150&height=150", "Referer=<p_ServerURL>/cyclos/Network01", ENDITEM,
		"URL=../content/images/x97Joy1AzwhQRJehPyqRXGvsVP854cjw0qVMk0XcLCkpAAdTXGtPt4txz11aDDTN_625x245.png?_k=04186c5b68794be61ffa6bc7fb4a478817386a94&width=150&height=150", "Referer=<p_ServerURL>/cyclos/Network01", ENDITEM,*/
		LAST);

if(atoi(lr_eval_string("<myadv_cnt>"))>0)
	{
lr_end_transaction("BP02_05_MyAdvertisement",LR_PASS);
	}
	else
	{

lr_end_transaction("BP02_05_MyAdvertisement",LR_FAIL);
lr_output_message("My advert page load failed at = %s",lr_eval_string("<p_timestamp>"));
	}
	
lr_think_time(5);	
	
web_reg_find("Fail=NotFound","Search=Body","SaveCount=newad_cnt","Text=Create new advertisement",LAST);

web_add_header("Session-Prefix","<c_sessionID>");

lr_start_transaction("BP02_06_NewAdvert");

	web_url("loadTranslations_5",
		"URL=<p_ServerURL>/cyclos/Network01/content/loadTranslations?_k=<c_KID>&cacheKey=<c_KID>&languageId=<languageId>&languageLastModified=&submodule=MARKETPLACE.ADVERTISEMENTS&submodule=SYSTEM.ENTITY_LOGS&submodule=USERS.ADDRESSES",
		"TargetFrame=",
		"Resource=0",
		"RecContentType=application/json",
		"Referer=<p_ServerURL>/cyclos/Network01",
		"Snapshot=t19.inf",
		"Mode=HTML",
		LAST);

	web_add_header("Origin","<p_ServerURL>");

	
	web_reg_save_param_json(
		"ParamName=c_carId",
		"QueryString=$.result.categories[0].id",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=No",
		LAST);
	
	web_reg_save_param_json(
		"ParamName=c_propertyId",
		"QueryString=$.result.categories[1].id",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=No",
		LAST);
	
	web_reg_save_param_json(
		"ParamName=c_MediaId",
		"QueryString=$.result.categories[2].id",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=No",
		LAST);
	
	web_reg_save_param_json(
		"ParamName=c_ServicesId",
		"QueryString=$.result.categories[3].id",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=No",
		LAST);
/*original value = -2764790703747482922*/	
	web_reg_save_param_json(
		"ParamName=c_unitID",
		"QueryString=$.result.currencies[0].id",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=No",
		LAST);

web_add_header("Session-Prefix","<c_sessionID>");

	web_custom_request("productsAndServices_4",
		"URL=<p_ServerURL>/cyclos/Network01/web-rpc/productsAndServices",
		"Method=POST",
		"TargetFrame=",
		"Resource=0",
		"RecContentType=application/json",
		"Referer=<p_ServerURL>/cyclos/Network01",
		"Snapshot=t20.inf",
		"Mode=HTML",
		"EncType=application/json",
		"Body={\"operation\":\"getDataForNew\", \"params\":[{\"class\":\"org.cyclos.model.marketplace.advertisements.AdDataParams\", \"type\":\"ADVERTISEMENT\", \"user\":{\"class\":\"org.cyclos.model.users.users.UserLocatorVO\", \"id\":\"<userId>\"}, \"basedOnId\":null}]}",
		EXTRARES,
		/*"URL=../content/themes/-2764790703747482922/image?_k=04186c5b68794be61ffa6bc7fb4a478817386a94&type=TOOLBAR_ICON&name=FONT", "Referer=<p_ServerURL>/cyclos/Network01", ENDITEM,
		"URL=../content/themes/-2764790703747482922/image?_k=04186c5b68794be61ffa6bc7fb4a478817386a94&type=TOOLBAR_ICON&name=INCREASE_SIZE", "Referer=<p_ServerURL>/cyclos/Network01", ENDITEM,
		"URL=../content/themes/-2764790703747482922/image?_k=04186c5b68794be61ffa6bc7fb4a478817386a94&type=TOOLBAR_ICON&name=DECREASE_SIZE", "Referer=<p_ServerURL>/cyclos/Network01", ENDITEM,
		"URL=../content/themes/-2764790703747482922/image?_k=04186c5b68794be61ffa6bc7fb4a478817386a94&type=TOOLBAR_ICON&name=FOREGROUND_COLOR", "Referer=<p_ServerURL>/cyclos/Network01", ENDITEM,
		"URL=../content/themes/-2764790703747482922/image?_k=04186c5b68794be61ffa6bc7fb4a478817386a94&type=TOOLBAR_ICON&name=BACKGROUND_COLOR", "Referer=<p_ServerURL>/cyclos/Network01", ENDITEM,
		"URL=../content/themes/-2764790703747482922.css?version=4.12", ENDITEM,
		"URL=../content/themes/-2764790703747482922/image?_k=04186c5b68794be61ffa6bc7fb4a478817386a94&type=TOOLBAR_ICON&name=BOLD", "Referer=<p_ServerURL>/cyclos/Network01", ENDITEM,
		"URL=../content/themes/-2764790703747482922/image?_k=04186c5b68794be61ffa6bc7fb4a478817386a94&type=TOOLBAR_ICON&name=ITALIC", "Referer=<p_ServerURL>/cyclos/Network01", ENDITEM,
		"URL=../content/themes/-2764790703747482922/image?_k=04186c5b68794be61ffa6bc7fb4a478817386a94&type=TOOLBAR_ICON&name=UNDERLINE", "Referer=<p_ServerURL>/cyclos/Network01", ENDITEM,
		"URL=../content/themes/-2764790703747482922/image?_k=04186c5b68794be61ffa6bc7fb4a478817386a94&type=TOOLBAR_ICON&name=STRIKE_THROUGH", "Referer=<p_ServerURL>/cyclos/Network01", ENDITEM,
		"URL=../content/themes/-2764790703747482922/image?_k=04186c5b68794be61ffa6bc7fb4a478817386a94&type=TOOLBAR_ICON&name=REMOVE_LINK", "Referer=<p_ServerURL>/cyclos/Network01", ENDITEM,
		"URL=../content/themes/-2764790703747482922/image?_k=04186c5b68794be61ffa6bc7fb4a478817386a94&type=TOOLBAR_ICON&name=EDIT_HTML", "Referer=<p_ServerURL>/cyclos/Network01", ENDITEM,
		"URL=../content/themes/-2764790703747482922/image?_k=04186c5b68794be61ffa6bc7fb4a478817386a94&type=TOOLBAR_ICON&name=JUSTIFY_LEFT", "Referer=<p_ServerURL>/cyclos/Network01", ENDITEM,
		"URL=../content/themes/-2764790703747482922/image?_k=04186c5b68794be61ffa6bc7fb4a478817386a94&type=TOOLBAR_ICON&name=INDENT", "Referer=<p_ServerURL>/cyclos/Network01", ENDITEM,
		"URL=../content/themes/-2764790703747482922/image?_k=04186c5b68794be61ffa6bc7fb4a478817386a94&type=TOOLBAR_ICON&name=REMOVE_FORMAT", "Referer=<p_ServerURL>/cyclos/Network01", ENDITEM,
		"URL=../content/themes/-2764790703747482922/image?_k=04186c5b68794be61ffa6bc7fb4a478817386a94&type=TOOLBAR_ICON&name=JUSTIFY_CENTER", "Referer=<p_ServerURL>/cyclos/Network01", ENDITEM,
		"URL=../content/themes/-2764790703747482922/image?_k=04186c5b68794be61ffa6bc7fb4a478817386a94&type=TOOLBAR_ICON&name=OUTDENT", "Referer=<p_ServerURL>/cyclos/Network01", ENDITEM,
		"URL=../content/themes/-2764790703747482922/image?_k=04186c5b68794be61ffa6bc7fb4a478817386a94&type=TOOLBAR_ICON&name=JUSTIFY_RIGHT", "Referer=<p_ServerURL>/cyclos/Network01", ENDITEM,
		"URL=../content/themes/-2764790703747482922/image?_k=04186c5b68794be61ffa6bc7fb4a478817386a94&type=TOOLBAR_ICON&name=ORDERED_LIST", "Referer=<p_ServerURL>/cyclos/Network01", ENDITEM,
		"URL=../content/themes/-2764790703747482922/image?_k=04186c5b68794be61ffa6bc7fb4a478817386a94&type=TOOLBAR_ICON&name=CREATE_LINK", "Referer=<p_ServerURL>/cyclos/Network01", ENDITEM,
		"URL=../content/themes/-2764790703747482922/image?_k=04186c5b68794be61ffa6bc7fb4a478817386a94&type=TOOLBAR_ICON&name=UNORDERED_LIST", "Referer=<p_ServerURL>/cyclos/Network01", ENDITEM,
		"URL=../push-notifications?clientId=c5195b36-0505-44da-88e6-6611b39bb79b_1565723237216&eventTypes=loggedOut,newMessage,newNotification,deviceConfirmation&Session-Prefix=<c_sessionID>", "Referer=<p_ServerURL>/cyclos/Network01", ENDITEM,
		*/
		LAST);

if(atoi(lr_eval_string("<newad_cnt>"))>0)
	{
lr_end_transaction("BP02_06_NewAdvert",LR_PASS);
	}
	else
	{

lr_end_transaction("BP02_06_NewAdvert",LR_FAIL);
lr_output_message("New Advert page load failed at = %s",lr_eval_string("<p_timestamp>"));
	}
lr_think_time(5);	


web_add_auto_header("Origin","<p_ServerURL>");

web_add_auto_header("Session-Prefix","<c_sessionID>");

/*Correlation comment: Automatic rules - Do not change!  
Original value='-2764790696097072426' 
Name ='CorrelationParameter' 
Type ='Rule' 
AppName ='AribaBuyer' 
RuleName ='c_paymentID'*/
	web_reg_save_param_json(
		"ParamName=c_resultID1",
		"QueryString=$.result.id",
		SEARCH_FILTERS,
		"Scope=Body",
		LAST);


lr_start_transaction("BP02_07_Save");

	web_submit_data("temp",
		"Action=<p_ServerURL>/cyclos/Network01/content/images/temp?_k=<c_KID>",
		"Method=POST",
		"EncType=multipart/form-data",
		"TargetFrame=",
		"RecContentType=application/json",
		"Referer=<p_ServerURL>/cyclos/Network01",
		"Snapshot=t22.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=target", "Value=ADVERTISEMENT", ENDITEM,
		"Name=guestKey", "Value=<p_hex><p_hex><p_hex><p_hex><p_hex><p_hex><p_hex><p_hex><p_hex><p_hex><p_hex><p_hex><p_hex><p_hex><p_hex><p_hex><p_hex>", ENDITEM,
		"Name=userId", "Value=<userId>", ENDITEM,
		"Name=file", "Value=/Images//<p_imageID>.jpg", "File=yes", ENDITEM,
		LAST);

web_reg_save_param("c_productID", "LB=result\":\"", "RB=\"}",LAST);
	
lr_save_string(lr_eval_string("<p_category>"),"P_categorytype");
	               
	if(strcmp(lr_eval_string("<P_categorytype>") ,"Cars")==0)
	{ 
		web_custom_request("productsAndServices_5",
		"URL=<p_ServerURL>/cyclos/Network01/web-rpc/productsAndServices",
		"Method=POST",
		"TargetFrame=",
		"Resource=0",
		"RecContentType=application/json",
		"Referer=<p_ServerURL>/cyclos/Network01",
		"Snapshot=t23.inf",
		"Mode=HTML",
		"EncType=application/json",
		"Body={\"operation\":\"save\", \"params\":[{\"class\":\"org.cyclos.model.marketplace.advertisements.AdvertisementDTO\", \"owner\":{\"class\":\"org.cyclos.model.users.users.UserVO\", \"display\":\"<p_username>\", \"shortDisplay\":\"<p_username>\", \"id\":\"<userId>\"}, \"categories\":[{\"class\":\"org.cyclos.model.marketplace.categories.AdCategoryDetailedVO\", \"active\":true, \"images\":[], \"childrenCount\":0, \"id\":\"<c_carId>\", \"name\":\"<p_category>\"}], \"addresses\":[], \"customValues\":[], \"publicationPeriod\":{\"class\":\"org.cyclos.model.utils.DatePeriodDTO\", \"end\":\"<p_endDate>T22:59:59.999Z\", \"begin\":\"<p_beginDate>T00:00:00.000+01:00\"}, \"promotionalPeriodActive\":false, \"uploadedImages\":[{\"class\":\"org.cyclos.model.system.images.ImageVO\", \"key\":\"<p_hex><p_hex><p_hex><p_hex><p_hex><p_hex><p_hex><p_hex><p_hex><p_hex><p_hex><p_hex><p_hex><p_hex><p_hex><p_hex><p_hex>_<p_imagewdth>x<p_imagehgt>.jpeg\", \"nature\":\"TEMP\", \"width\":<p_imagewdth>, \"height\":<p_imagehgt>, \"convertedToJpeg\":false, \"contentType\":\"image/jpeg\", \"length\":23973, \"name\":\"<p_imageID>"
		"\", \"id\":\"<c_resultID1>\", \"lastModified\":\"<p_endDate>T20:10:34.421+01:00\", \"lastModifiedInMillis\":\"<p_time>\"}], \"status\":\"ACTIVE\", \"price\":{\"class\":\"org.cyclos.model.utils.CurrencyAmountDTO\", \"amount\":\"20.00\", \"currency\":{\"class\":\"org.cyclos.model.banking.currencies.CurrencyVO\", \"symbol\":\"U\", \"precision\":2, \"global\":false, \"prefix\":\"U \", \"internalName\":\"unit\", \"id\":\"<c_unitID>\", \"name\":\"Units\"}}, \"name\":\"TEST TITLE_<p_random>\", \"description\":\"THIS IS TEST DESCRIPTION_<p_random>\"}]}",
		LAST);   	
	}
	 else
	{
	 if(strcmp(lr_eval_string("<P_categorytype>") , "Property")==0)              		
	{
	     web_custom_request("productsAndServices_5",
		"URL=<p_ServerURL>/cyclos/Network01/web-rpc/productsAndServices",
		"Method=POST",
		"TargetFrame=",
		"Resource=0",
		"RecContentType=application/json",
		"Referer=<p_ServerURL>/cyclos/Network01",
		"Snapshot=t23.inf",
		"Mode=HTML",
		"EncType=application/json",
		"Body={\"operation\":\"save\", \"params\":[{\"class\":\"org.cyclos.model.marketplace.advertisements.AdvertisementDTO\", \"owner\":{\"class\":\"org.cyclos.model.users.users.UserVO\", \"display\":\"<p_username>\", \"shortDisplay\":\"<p_username>\", \"id\":\"<userId>\"}, \"categories\":[{\"class\":\"org.cyclos.model.marketplace.categories.AdCategoryDetailedVO\", \"active\":true, \"images\":[], \"childrenCount\":0, \"id\":\"<c_propertyId>\", \"name\":\"<p_category>\"}], \"addresses\":[], \"customValues\":[], \"publicationPeriod\":{\"class\":\"org.cyclos.model.utils.DatePeriodDTO\", \"end\":\"<p_endDate>T22:59:59.999Z\", \"begin\":\"<p_beginDate>T00:00:00.000+01:00\"}, \"promotionalPeriodActive\":false, \"uploadedImages\":[{\"class\":\"org.cyclos.model.system.images.ImageVO\", \"key\":\"<p_hex><p_hex><p_hex><p_hex><p_hex><p_hex><p_hex><p_hex><p_hex><p_hex><p_hex><p_hex><p_hex><p_hex><p_hex><p_hex><p_hex>_<p_imagewdth>x<p_imagehgt>.jpeg\", \"nature\":\"TEMP\", \"width\":<p_imagewdth>, \"height\":<p_imagehgt>, \"convertedToJpeg\":false, \"contentType\":\"image/jpeg\", \"length\":23973, \"name\":\"<p_imageID>"
		"\", \"id\":\"<c_resultID1>\", \"lastModified\":\"<p_beginDate>T20:10:34.421+01:00\", \"lastModifiedInMillis\":\"<p_time>\"}], \"status\":\"ACTIVE\", \"price\":{\"class\":\"org.cyclos.model.utils.CurrencyAmountDTO\", \"amount\":\"20.00\", \"currency\":{\"class\":\"org.cyclos.model.banking.currencies.CurrencyVO\", \"symbol\":\"U\", \"precision\":2, \"global\":false, \"prefix\":\"U \", \"internalName\":\"unit\", \"id\":\"<c_unitID>\", \"name\":\"Units\"}}, \"name\":\"TEST TITLE_<p_random>\", \"description\":\"THIS IS TEST DESCRIPTION_<p_random>\"}]}",
		LAST);	
	}
	 else
	{
	if(strcmp(lr_eval_string("<P_categorytype>") , "Media")==0){
	     web_custom_request("productsAndServices_5",
		"URL=<p_ServerURL>/cyclos/Network01/web-rpc/productsAndServices",
		"Method=POST",
		"TargetFrame=",
		"Resource=0",
		"RecContentType=application/json",
		"Referer=<p_ServerURL>/cyclos/Network01",
		"Snapshot=t23.inf",
		"Mode=HTML",
		"EncType=application/json",
		"Body={\"operation\":\"save\", \"params\":[{\"class\":\"org.cyclos.model.marketplace.advertisements.AdvertisementDTO\", \"owner\":{\"class\":\"org.cyclos.model.users.users.UserVO\", \"display\":\"<p_username>\", \"shortDisplay\":\"<p_username>\", \"id\":\"<userId>\"}, \"categories\":[{\"class\":\"org.cyclos.model.marketplace.categories.AdCategoryDetailedVO\", \"active\":true, \"images\":[], \"childrenCount\":0, \"id\":\"<c_MediaId>\", \"name\":\"<p_category>\"}], \"addresses\":[], \"customValues\":[], \"publicationPeriod\":{\"class\":\"org.cyclos.model.utils.DatePeriodDTO\", \"end\":\"<p_endDate>T22:59:59.999Z\", \"begin\":\"<p_beginDate>T00:00:00.000+01:00\"}, \"promotionalPeriodActive\":false, \"uploadedImages\":[{\"class\":\"org.cyclos.model.system.images.ImageVO\", \"key\":\"<p_hex><p_hex><p_hex><p_hex><p_hex><p_hex><p_hex><p_hex><p_hex><p_hex><p_hex><p_hex><p_hex><p_hex><p_hex><p_hex><p_hex>_<p_imagewdth>x<p_imagehgt>.jpeg\", \"nature\":\"TEMP\", \"width\":<p_imagewdth>, \"height\":<p_imagehgt>, \"convertedToJpeg\":false, \"contentType\":\"image/jpeg\", \"length\":23973, \"name\":\"<p_imageID>"
		"\", \"id\":\"<c_resultID1>\", \"lastModified\":\"<p_beginDate>T20:10:34.421+01:00\", \"lastModifiedInMillis\":\"<p_time>\"}], \"status\":\"ACTIVE\", \"price\":{\"class\":\"org.cyclos.model.utils.CurrencyAmountDTO\", \"amount\":\"20.00\", \"currency\":{\"class\":\"org.cyclos.model.banking.currencies.CurrencyVO\", \"symbol\":\"U\", \"precision\":2, \"global\":false, \"prefix\":\"U \", \"internalName\":\"unit\", \"id\":\"<c_unitID>\", \"name\":\"Units\"}}, \"name\":\"TEST TITLE_<p_random>\", \"description\":\"THIS IS TEST DESCRIPTION_<p_random>\"}]}",
		LAST);		
	 }
	 else
	{
	if(strcmp(lr_eval_string("<P_categorytype>") , "Services")==0)
	{   
		web_custom_request("productsAndServices_5",
		"URL=<p_ServerURL>/cyclos/Network01/web-rpc/productsAndServices",
		"Method=POST",
		"TargetFrame=",
		"Resource=0",
		"RecContentType=application/json",
		"Referer=<p_ServerURL>/cyclos/Network01",
		"Snapshot=t23.inf",
		"Mode=HTML",
		"EncType=application/json",
		"Body={\"operation\":\"save\", \"params\":[{\"class\":\"org.cyclos.model.marketplace.advertisements.AdvertisementDTO\", \"owner\":{\"class\":\"org.cyclos.model.users.users.UserVO\", \"display\":\"<p_username>\", \"shortDisplay\":\"<p_username>\", \"id\":\"<userId>\"}, \"categories\":[{\"class\":\"org.cyclos.model.marketplace.categories.AdCategoryDetailedVO\", \"active\":true, \"images\":[], \"childrenCount\":0, \"id\":\"<c_ServicesId>\", \"name\":\"<p_category>\"}], \"addresses\":[], \"customValues\":[], \"publicationPeriod\":{\"class\":\"org.cyclos.model.utils.DatePeriodDTO\", \"end\":\"<p_endDate>T22:59:59.999Z\", \"begin\":\"<p_beginDate>T00:00:00.000+01:00\"}, \"promotionalPeriodActive\":false, \"uploadedImages\":[{\"class\":\"org.cyclos.model.system.images.ImageVO\", \"key\":\"<p_hex><p_hex><p_hex><p_hex><p_hex><p_hex><p_hex><p_hex><p_hex><p_hex><p_hex><p_hex><p_hex><p_hex><p_hex><p_hex><p_hex>_<p_imagewdth>x<p_imagehgt>.jpeg\", \"nature\":\"TEMP\", \"width\":<p_imagewdth>, \"height\":<p_imagehgt>, \"convertedToJpeg\":false, \"contentType\":\"image/jpeg\", \"length\":23973, \"name\":\"<p_imageID>"
		"\", \"id\":\"<c_resultID1>\", \"lastModified\":\"<p_beginDate>T20:10:34.421+01:00\", \"lastModifiedInMillis\":\"<p_time>\"}], \"status\":\"ACTIVE\", \"price\":{\"class\":\"org.cyclos.model.utils.CurrencyAmountDTO\", \"amount\":\"20.00\", \"currency\":{\"class\":\"org.cyclos.model.banking.currencies.CurrencyVO\", \"symbol\":\"U\", \"precision\":2, \"global\":false, \"prefix\":\"U \", \"internalName\":\"unit\", \"id\":\"<c_unitID>\", \"name\":\"Units\"}}, \"name\":\"TEST TITLE_<p_random>\", \"description\":\"THIS IS TEST DESCRIPTION_<p_random>\"}]}",
		LAST);	
	               					
	}
	else
	{
	     lr_error_message ("My logic doesn't work, Save failed");
         lr_exit(LR_EXIT_VUSER, LR_FAIL);	
	}
	 }
	 }
	 }

web_reg_find("Fail=NotFound","Search=Body","SaveCount=save_cnt","Text=ACTIVE",LAST);

	web_custom_request("productsAndServices_6", 
		"URL=<p_ServerURL>/cyclos/Network01/web-rpc/productsAndServices", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=<p_ServerURL>/cyclos/Network01", 
		"Snapshot=t24.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"operation\":\"getData\", \"params\":[\"<c_productID>\"]}", 
		EXTRARES, 
		//"Url=../push-notifications?clientId=c5195b36-0505-44da-88e6-6611b39bb79b_1565723237216&eventTypes=loggedOut,newMessage,newNotification,deviceConfirmation&Session-Prefix=<c_sessionID>", "Referer=<p_ServerURL>/cyclos/Network01", ENDITEM, 
		LAST);

if(atoi(lr_eval_string("<save_cnt>"))>0)
	{
lr_end_transaction("BP02_07_Save",LR_PASS);
	}
	else
	{

lr_end_transaction("BP02_07_Save",LR_FAIL);
lr_output_message("Save Adv failed at = %s",lr_eval_string("<p_timestamp>"));
	}
lr_think_time(5);		 
	 
lr_start_transaction("BP02_08_MarketPlace");

web_reg_find("Fail=NotFound","Search=Body","SaveCount=mrktplc_cnt2","Text=ADVERTISEMENT",LAST);

	web_custom_request("productsAndServices_7", 
		"URL=<p_ServerURL>/cyclos/Network01/web-rpc/productsAndServices", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=<p_ServerURL>/cyclos/Network01", 
		"Snapshot=t25.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"operation\":\"getAdSearchData\", \"params\":[null,false]}", 
		LAST);

if(atoi(lr_eval_string("<mrktplc_cnt2>"))>0)
	{
lr_end_transaction("BP02_08_MarketPlace",LR_PASS);
	}
	else
	{

lr_end_transaction("BP02_08_MarketPlace",LR_FAIL);
lr_output_message("Marketplace page load failed at = %s",lr_eval_string("<p_timestamp>"));
	}

lr_think_time(5);

	web_reg_save_param_json(
		"ParamName=c_adselectid",
		"QueryString=$.result.pageItems[0].id",
		SEARCH_FILTERS,
		"Scope=Body",
		LAST);

web_reg_find("Fail=NotFound","Search=Body","SaveCount=seachad_cnt2","Text=ACTIVE",LAST);

lr_start_transaction("BP02_09_searchItem");

	web_custom_request("productsAndServices_8", 
		"URL=<p_ServerURL>/cyclos/Network01/web-rpc/productsAndServices", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=<p_ServerURL>/cyclos/Network01", 
		"Snapshot=t27.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"operation\":\"search\", \"params\":[{\"class\":\"org.cyclos.model.marketplace.advertisements.BasicAdQuery\", \"type\":\"ADVERTISEMENT\", \"groups\":[], \"orderBy\":\"DATE\", \"returnEditable\":false, \"hasImages\":false, \"currentPage\":0, \"pageSize\":40, \"state\":\"INITIAL\", \"userProfileFields\":[], \"adCustomValues\":[], \"priceRange\":null, \"keywords\":\"TEST TITLE <p_random>\", \"addressResult\":\"NO_ADDRESSES\"}]}", 
		LAST);

if(atoi(lr_eval_string("<seachad_cnt2>"))>0)
	{
lr_end_transaction("BP02_09_searchItem",LR_PASS);
	}
	else
	{

lr_end_transaction("BP02_09_searchItem",LR_FAIL);
lr_output_message("Search ad failed at = %s",lr_eval_string("<p_timestamp>"));
	}

web_reg_find("Fail=NotFound","Search=Body","SaveCount=openad_cnt","Text=Hide ad",LAST);

web_add_auto_header("Session-Prefix","<c_sessionID>");

lr_start_transaction("BP02_10_OpenItem");

	web_url("loadTranslations_6",
		"URL=<p_ServerURL>/cyclos/Network01/content/loadTranslations?_k=<c_KID>&cacheKey=<c_KID>&languageId=<languageId>&languageLastModified=&submodule=MARKETPLACE.ADVERTISEMENTS&submodule=MARKETPLACE.WEBSHOP_ORDERS&submodule=MARKETPLACE.WEBSHOP_DELIVERY_METHODS&submodule=USERS.ADDRESSES&submodule=MESSAGING.MESSAGES",
		"TargetFrame=",
		"Resource=0",
		"RecContentType=application/json",
		"Referer=<p_ServerURL>/cyclos/Network01",
		"Snapshot=t28.inf",
		"Mode=HTML",
		LAST);

	web_add_auto_header("Origin", 
		"<p_ServerURL>");

web_add_header("Session-Prefix","<c_sessionID>");

	web_custom_request("productsAndServices_10",
		"URL=<p_ServerURL>/cyclos/Network01/web-rpc/productsAndServices",
		"Method=POST",
		"TargetFrame=",
		"Resource=0",
		"RecContentType=application/json",
		"Referer=<p_ServerURL>/cyclos/Network01",
		"Snapshot=t29.inf",
		"Mode=HTML",
		"EncType=application/json",
		"Body={\"operation\":\"getViewData\", \"params\":[{\"class\":\"org.cyclos.model.marketplace.advertisements.BasicAdVO\", \"id\":\"<c_adselectid>\"}]}",
		EXTRARES,
		//"URL=../content/images/VmkPuZMSrbQlKv3Vx60kTzNRDtW0dwJnX1tKVFDUBloH1QVLarncKFh6ErHY8QOR_476x317.jpeg?_k=04186c5b68794be61ffa6bc7fb4a478817386a94&width=240&height=240", "Referer=<p_ServerURL>/cyclos/Network01", ENDITEM,
		LAST);

if(atoi(lr_eval_string("<openad_cnt>"))>0)
	{
lr_end_transaction("BP02_10_OpenItem",LR_PASS);
	}
	else
	{

lr_end_transaction("BP02_10_OpenItem",LR_FAIL);
lr_output_message("Search ad failed at = %s",lr_eval_string("<p_timestamp>"));
	}

	return 0;
}