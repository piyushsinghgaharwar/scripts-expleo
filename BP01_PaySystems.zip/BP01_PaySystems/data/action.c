Action()
{

	web_set_sockets_option("SSL_VERSION", "TLS1.2");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_url("Network01", 
		"URL=http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com/cyclos/Network01", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=Network01/js/load-image.all.min.js?_k=04186c5b68794be61ffa6bc7fb4a478817386a94", ENDITEM, 
		"Url=Network01/js/script.min.js?_k=04186c5b68794be61ffa6bc7fb4a478817386a94", ENDITEM, 
		"Url=Network01/cyclos.gwt/cyclos.gwt.nocache.js?_k=04186c5b68794be61ffa6bc7fb4a478817386a94", ENDITEM, 
		"Url=Network01/cyclos.gwt/44283D0B5AB2110F2E0E4D288EF9A291.cache.js", ENDITEM, 
		"Url=Network01/content/themes/-2764790703747482922.css?_k=04186c5b68794be61ffa6bc7fb4a478817386a94&lastModified=1562772279057", ENDITEM, 
		"Url=Network01/cyclos.gwt/clear.cache.gif", ENDITEM, 
		"Url=Network01/content/images/currentConfiguration/SYSTEM_LOGO?mod=1564996692527", ENDITEM, 
		"Url=Network01/push-notifications?clientId=606c4b14-dde7-403f-bea5-fee87bf79e28_1565550606103&eventTypes=loggedOut,newMessage,newNotification,deviceConfirmation&Session-Prefix=yIyo6NcOojsHItAx", ENDITEM, 
		"Url=Network01/content/themes/-2764790703747482922/image?_k=04186c5b68794be61ffa6bc7fb4a478817386a94&type=DASHBOARD_ACTION&name=ACCOUNT_INFO", ENDITEM, 
		"Url=Network01/content/themes/-2764790703747482922/image?_k=04186c5b68794be61ffa6bc7fb4a478817386a94&type=DASHBOARD_ACTION&name=PAYMENT_USER_TO_USER", ENDITEM, 
		"Url=Network01/content/themes/-2764790703747482922/image?_k=04186c5b68794be61ffa6bc7fb4a478817386a94&type=DASHBOARD_ACTION&name=PAYMENT_USER_TO_SYSTEM", ENDITEM, 
		"Url=Network01/content/themes/-2764790703747482922/image?_k=04186c5b68794be61ffa6bc7fb4a478817386a94&type=DASHBOARD_ACTION&name=SEARCH_USERS", ENDITEM, 
		"Url=Network01/content/themes/-2764790703747482922/image?_k=04186c5b68794be61ffa6bc7fb4a478817386a94&type=DASHBOARD_ACTION&name=CONTACTS", ENDITEM, 
		"Url=Network01/content/themes/-2764790703747482922/image?_k=04186c5b68794be61ffa6bc7fb4a478817386a94&type=DASHBOARD_ACTION&name=UPDATE_PROFILE", ENDITEM, 
		"Url=Network01/content/themes/-2764790703747482922/image?_k=04186c5b68794be61ffa6bc7fb4a478817386a94&type=DASHBOARD_ACTION&name=SEND_MESSAGE", ENDITEM, 
		"Url=Network01/content/themes/-2764790703747482922/image?_k=04186c5b68794be61ffa6bc7fb4a478817386a94&type=DASHBOARD_ACTION&name=VIEW_MESSAGES", ENDITEM, 
		"Url=Network01/content/themes/-2764790703747482922/image?_k=04186c5b68794be61ffa6bc7fb4a478817386a94&type=DASHBOARD_ACTION&name=SEARCH_ADS", ENDITEM, 
		"Url=Network01/content/themes/-2764790703747482922/image?_k=04186c5b68794be61ffa6bc7fb4a478817386a94&type=DASHBOARD_ACTION&name=PLACE_AD", ENDITEM, 
		"Url=Network01/content/themes/-2764790703747482922/image?_k=04186c5b68794be61ffa6bc7fb4a478817386a94&type=DASHBOARD_ACTION&name=VIEW_NOTIFICATIONS", ENDITEM, 
		"Url=Network01/content/themes/-2764790703747482922/image?_k=04186c5b68794be61ffa6bc7fb4a478817386a94&type=DASHBOARD_ACTION&name=DOCUMENTATION", ENDITEM, 
		"Url=Network01/content/themes/-2764790703747482922/image?_k=04186c5b68794be61ffa6bc7fb4a478817386a94&type=DASHBOARD_STATUS&name=ACCOUNT_BALANCE", ENDITEM, 
		"Url=Network01/content/themes/-2764790703747482922/image?_k=04186c5b68794be61ffa6bc7fb4a478817386a94&type=DASHBOARD_STATUS&name=MY_ADS", ENDITEM, 
		"Url=Network01/content/themes/-2764790703747482922/image?_k=04186c5b68794be61ffa6bc7fb4a478817386a94&type=DASHBOARD_STATUS&name=UNREAD_MESSAGES", ENDITEM, 
		"Url=Network01/content/themes/-2764790703747482922/image?_k=04186c5b68794be61ffa6bc7fb4a478817386a94&type=DASHBOARD_STATUS&name=LAST_LOGIN", ENDITEM, 
		"Url=Network01/cyclos.gwt/deferredjs/44283D0B5AB2110F2E0E4D288EF9A291/10.cache.js", ENDITEM, 
		"Url=Network01/cyclos.gwt/deferredjs/44283D0B5AB2110F2E0E4D288EF9A291/4.cache.js", ENDITEM, 
		LAST);

	web_add_auto_header("Channel", 
		"main");

	web_add_header("Origin", 
		"http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com");

	web_custom_request("initializationService", 
		"URL=http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com/cyclos/Network01/web-rpc/initializationService", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com/cyclos/Network01", 
		"Snapshot=t2.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"operation\":\"getInitializationData\", \"params\":[null,null]}", 
		LAST);

	web_url("loadTranslations", 
		"URL=http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com/cyclos/Network01/content/loadTranslations?_k=04186c5b68794be61ffa6bc7fb4a478817386a94&cacheKey=04186c5b68794be61ffa6bc7fb4a478817386a94&languageId=-2764790703814591786&languageLastModified=&submodule=GENERAL.ERRORS&submodule=GENERAL.MENU&submodule=GENERAL.UI&submodule=ACCESS.LOGIN&submodule=MESSAGING.NOTIFICATIONS", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com/cyclos/Network01", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		LAST);

	web_reg_find("Text=Welcome to Network 01", 
		LAST);

	web_add_header("Origin", 
		"http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com");

	web_custom_request("initializationService_2", 
		"URL=http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com/cyclos/Network01/web-rpc/initializationService", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com/cyclos/Network01", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"operation\":\"getHomeData\", \"params\":[]}", 
		LAST);

	/* Application Launched */

	/* Click on Sign in link */

	lr_think_time(15);

	web_url("loadTranslations_2", 
		"URL=http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com/cyclos/Network01/content/loadTranslations?_k=04186c5b68794be61ffa6bc7fb4a478817386a94&cacheKey=04186c5b68794be61ffa6bc7fb4a478817386a94&languageId=-2764790703814591786&languageLastModified=&submodule=ACCESS.LOGIN", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com/cyclos/Network01", 
		"Snapshot=t5.inf", 
		"Mode=HTML", 
		LAST);

	/* SUBMIT LOGIN DETAILS */

	web_add_auto_header("Origin", 
		"http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com");

	lr_think_time(42);

	web_submit_data("login", 
		"Action=http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com/cyclos/Network01/content/login?_k=04186c5b68794be61ffa6bc7fb4a478817386a94", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/plain", 
		"Referer=http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com/cyclos/Network01", 
		"Snapshot=t6.inf", 
		"Mode=HTML", 
		ITEMDATA, 
		"Name=password", "Value=password123", ENDITEM, 
		"Name=principal", "Value=PerfTestUser3", ENDITEM, 
		"Name=principalType", "Value=username", ENDITEM, 
		LAST);

	web_add_auto_header("Session-Prefix", 
		"yIyo6NcOojsHItAx");

	web_custom_request("initializationService_3", 
		"URL=http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com/cyclos/Network01/web-rpc/initializationService", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com/cyclos/Network01", 
		"Snapshot=t7.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"operation\":\"getInitializationData\", \"params\":[null,null]}", 
		LAST);

	web_custom_request("initializationService_4", 
		"URL=http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com/cyclos/Network01/web-rpc/initializationService", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com/cyclos/Network01", 
		"Snapshot=t8.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"operation\":\"getHomeData\", \"params\":[]}", 
		LAST);

	/* CLICK ON ACCOUNT INFO TAB */

	web_revert_auto_header("Origin");

	web_url("loadTranslations_3", 
		"URL=http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com/cyclos/Network01/content/loadTranslations?_k=04186c5b68794be61ffa6bc7fb4a478817386a94&cacheKey=04186c5b68794be61ffa6bc7fb4a478817386a94&languageId=-2764790703814591786&languageLastModified=&submodule=BANKING.ACCOUNTS&submodule=BANKING.TRANSFERS", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com/cyclos/Network01", 
		"Snapshot=t9.inf", 
		"Mode=HTML", 
		LAST);

	web_add_header("Origin", 
		"http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com");

	web_custom_request("accountService", 
		"URL=http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com/cyclos/Network01/web-rpc/accountService", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com/cyclos/Network01", 
		"Snapshot=t10.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"operation\":\"getAccountsSummary\", \"params\":[{\"class\":\"org.cyclos.model.users.users.UserVO\", \"id\":\"-2764790703445493034\"},null]}", 
		LAST);

	web_url("loadTranslations_4", 
		"URL=http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com/cyclos/Network01/content/loadTranslations?_k=04186c5b68794be61ffa6bc7fb4a478817386a94&cacheKey=04186c5b68794be61ffa6bc7fb4a478817386a94&languageId=-2764790703814591786&languageLastModified=&submodule=BANKING.ACCOUNTS&submodule=BANKING.TRANSACTIONS&submodule=BANKING.TRANSFERS&submodule=BANKING.RATES&submodule=USERS.USERS", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com/cyclos/Network01", 
		"Snapshot=t11.inf", 
		"Mode=HTML", 
		LAST);

	web_add_auto_header("Origin", 
		"http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com");

	web_custom_request("accountService_2", 
		"URL=http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com/cyclos/Network01/web-rpc/accountService", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com/cyclos/Network01", 
		"Snapshot=t12.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"operation\":\"getAccountHistoryData\", \"params\":[{\"class\":\"org.cyclos.model.banking.accounts.AccountVO\", \"id\":\"-2764790703512601898\"},\"PARAM_NO_UNLIMITED\"]}", 
		LAST);

	web_custom_request("accountService_3", 
		"URL=http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com/cyclos/Network01/web-rpc/accountService", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com/cyclos/Network01", 
		"Snapshot=t13.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"operation\":\"searchAccountHistory\", \"params\":[{\"class\":\"org.cyclos.model.banking.accounts.AccountHistoryQuery\", \"account\":{\"class\":\"org.cyclos.model.banking.accounts.AccountVO\", \"owner\":{\"class\":\"org.cyclos.model.users.users.UserVO\", \"display\":\"PerfTestUser3\", \"shortDisplay\":\"PerfTestUser3\", \"id\":\"-2764790703445493034\"}, \"type\":{\"class\":\"org.cyclos.model.banking.accounttypes.AccountTypeVO\", \"global\":false, \"nature\":\"USER\", \"internalName\":\""
		"user\", \"id\":\"-2764790703680374058\", \"name\":\"Member account\"}, \"active\":true, \"id\":\"-2764790703512601898\"}, \"usersWithImage\":false, \"orderBy\":\"DATE_DESC\", \"preselectedPeriod\":{\"class\":\"org.cyclos.model.utils.PeriodPreselectorOptionData\", \"name\":\"Last 12 months\", \"type\":\"PRESELECTED\", \"period\":{\"class\":\"org.cyclos.model.utils.DatePeriodDTO\", \"end\":\"2019-08-11T23:59:59.999+01:00\", \"begin\":\"2018-08-11T00:00:00.000+01:00\"}, \"defaultOption\":true}, \""
		"fromCurrentAccessClient\":false, \"includeGeneratedByAccessClient\":false, \"currentPage\":0, \"pageSize\":40, \"statuses\":[]}]}", 
		LAST);

	web_reg_find("Text=Member account", 
		LAST);

	web_revert_auto_header("Channel");

	web_revert_auto_header("Origin");

	web_revert_auto_header("Session-Prefix");

	web_add_auto_header("Channel", 
		"main");

	web_add_header("Origin", 
		"http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com");

	web_custom_request("accountService_4", 
		"URL=http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com/cyclos/Network01/web-rpc/accountService", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com/cyclos/Network01", 
		"Snapshot=t14.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"operation\":\"getAccountHistoryStatus\", \"params\":[{\"class\":\"org.cyclos.model.banking.accounts.AccountHistoryQuery\", \"account\":{\"class\":\"org.cyclos.model.banking.accounts.AccountVO\", \"owner\":{\"class\":\"org.cyclos.model.users.users.UserVO\", \"display\":\"PerfTestUser3\", \"shortDisplay\":\"PerfTestUser3\", \"id\":\"-2764790703445493034\"}, \"type\":{\"class\":\"org.cyclos.model.banking.accounttypes.AccountTypeVO\", \"global\":false, \"nature\":\"USER\", \"internalName\":\""
		"user\", \"id\":\"-2764790703680374058\", \"name\":\"Member account\"}, \"active\":true, \"id\":\"-2764790703512601898\"}, \"usersWithImage\":false, \"orderBy\":\"DATE_DESC\", \"preselectedPeriod\":{\"class\":\"org.cyclos.model.utils.PeriodPreselectorOptionData\", \"name\":\"Last 12 months\", \"type\":\"PRESELECTED\", \"period\":{\"class\":\"org.cyclos.model.utils.DatePeriodDTO\", \"end\":\"2019-08-11T23:59:59.999+01:00\", \"begin\":\"2018-08-11T00:00:00.000+01:00\"}, \"defaultOption\":true}, \""
		"fromCurrentAccessClient\":false, \"includeGeneratedByAccessClient\":false, \"currentPage\":0, \"pageSize\":40, \"statuses\":[]}]}", 
		LAST);

	/* CLICK ON PAYMENT TO SYSTEM */

	web_add_auto_header("Session-Prefix", 
		"yIyo6NcOojsHItAx");

	lr_think_time(15);

	web_url("loadTranslations_5", 
		"URL=http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com/cyclos/Network01/content/loadTranslations?_k=04186c5b68794be61ffa6bc7fb4a478817386a94&cacheKey=04186c5b68794be61ffa6bc7fb4a478817386a94&languageId=-2764790703814591786&languageLastModified=&submodule=BANKING.TRANSACTIONS&submodule=BANKING.TRANSFERS&submodule=BANKING.RATES&submodule=GENERAL.UI", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com/cyclos/Network01", 
		"Snapshot=t15.inf", 
		"Mode=HTML", 
		LAST);

	web_add_auto_header("Origin", 
		"http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com");

	web_custom_request("transactionService", 
		"URL=http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com/cyclos/Network01/web-rpc/transactionService", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com/cyclos/Network01", 
		"Snapshot=t16.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"operation\":\"getPaymentData\", \"params\":[{\"class\":\"org.cyclos.model.users.users.UserVO\", \"id\":\"-2764790703445493034\"},\"SYSTEM\",null]}", 
		LAST);

	web_reg_find("Text=Payment to system account", 
		LAST);

	web_custom_request("transactionService_2", 
		"URL=http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com/cyclos/Network01/web-rpc/transactionService", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com/cyclos/Network01", 
		"Snapshot=t17.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"operation\":\"getPaymentTypeData\", \"params\":[{\"class\":\"org.cyclos.model.users.users.UserVO\", \"display\":\"PerfTestUser3\", \"shortDisplay\":\"PerfTestUser3\", \"id\":\"-2764790703445493034\"},\"SYSTEM\",{\"class\":\"org.cyclos.model.banking.transfertypes.TransferTypeWithCurrencyVO\", \"currency\":{\"class\":\"org.cyclos.model.banking.currencies.CurrencyVO\", \"symbol\":\"U\", \"precision\":2, \"global\":false, \"prefix\":\"U \", \"internalName\":\"unit\", \"id\":\""
		"-2764790703747482922\", \"name\":\"Units\"}, \"enabled\":true, \"from\":{\"class\":\"org.cyclos.model.banking.accounttypes.AccountTypeVO\", \"global\":false, \"nature\":\"USER\", \"internalName\":\"user\", \"id\":\"-2764790703680374058\", \"name\":\"Member account\"}, \"to\":{\"class\":\"org.cyclos.model.banking.accounttypes.SystemAccountTypeVO\", \"limitType\":\"UNLIMITED\", \"global\":false, \"nature\":\"SYSTEM\", \"internalName\":\"debit\", \"id\":\"-2764790703747482922\", \"name\":\"Debit "
		"account\"}, \"nature\":\"PAYMENT\", \"requiresAuthorization\":false, \"ignoreAccountLimits\":false, \"allowFromCustomName\":false, \"allowToCustomName\":false, \"internalName\":\"user.toDebit\", \"id\":\"-2764790703579710762\", \"name\":\"Payment to Debit account\"}]}", 
		LAST);

	/* CLICK ON SUBMIT PAYMENT BUTTON */

	lr_think_time(27);

	web_custom_request("paymentService", 
		"URL=http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com/cyclos/Network01/web-rpc/paymentService", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com/cyclos/Network01", 
		"Snapshot=t18.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"operation\":\"preview\", \"params\":[{\"class\":\"org.cyclos.model.banking.transactions.PerformPaymentDTO\", \"from\":{\"class\":\"org.cyclos.model.users.users.UserVO\", \"display\":\"PerfTestUser3\", \"shortDisplay\":\"PerfTestUser3\", \"id\":\"-2764790703445493034\"}, \"to\":\"SYSTEM\", \"amount\":\"1.00\", \"type\":{\"class\":\"org.cyclos.model.banking.transfertypes.TransferTypeWithCurrencyVO\", \"currency\":{\"class\":\"org.cyclos.model.banking.currencies.CurrencyVO\", \"symbol\":\"U\""
		", \"precision\":2, \"global\":false, \"prefix\":\"U \", \"internalName\":\"unit\", \"id\":\"-2764790703747482922\", \"name\":\"Units\"}, \"enabled\":true, \"from\":{\"class\":\"org.cyclos.model.banking.accounttypes.AccountTypeVO\", \"global\":false, \"nature\":\"USER\", \"internalName\":\"user\", \"id\":\"-2764790703680374058\", \"name\":\"Member account\"}, \"to\":{\"class\":\"org.cyclos.model.banking.accounttypes.SystemAccountTypeVO\", \"limitType\":\"UNLIMITED\", \"global\":false, \"nature\":\""
		"SYSTEM\", \"internalName\":\"debit\", \"id\":\"-2764790703747482922\", \"name\":\"Debit account\"}, \"nature\":\"PAYMENT\", \"requiresAuthorization\":false, \"ignoreAccountLimits\":false, \"allowFromCustomName\":false, \"allowToCustomName\":false, \"internalName\":\"user.toDebit\", \"id\":\"-2764790703579710762\", \"name\":\"Payment to Debit account\"}, \"description\":\"THIS IS TEXT DESCRIPTION\", \"customValues\":[]}]}", 
		LAST);

	web_revert_auto_header("Origin");

	web_revert_auto_header("Channel");

	web_revert_auto_header("Session-Prefix");

	web_reg_find("Text=Payment review", 
		LAST);

	web_add_auto_header("Session-Prefix", 
		"yIyo6NcOojsHItAx");

	web_url("loadTranslations_6", 
		"URL=http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com/cyclos/Network01/content/loadTranslations?_k=04186c5b68794be61ffa6bc7fb4a478817386a94&cacheKey=04186c5b68794be61ffa6bc7fb4a478817386a94&languageId=-2764790703814591786&languageLastModified=&submodule=BANKING.TRANSFERS&submodule=BANKING.RATES&submodule=BANKING.TRANSACTIONS&submodule=ACCESS.PASSWORD_TYPES", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com/cyclos/Network01", 
		"Snapshot=t19.inf", 
		"Mode=HTML", 
		LAST);

	/* CONFIRM ON PAYMENT REVIEW */

	web_add_auto_header("Channel", 
		"main");

	web_add_header("Origin", 
		"http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com");

	lr_think_time(13);

	web_custom_request("paymentService_2", 
		"URL=http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com/cyclos/Network01/web-rpc/paymentService", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com/cyclos/Network01", 
		"Snapshot=t20.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"operation\":\"perform\", \"params\":[{\"class\":\"org.cyclos.model.banking.transactions.PerformPaymentDTO\", \"to\":\"SYSTEM\", \"from\":{\"class\":\"org.cyclos.model.users.users.UserVO\", \"locator\":{\"class\":\"org.cyclos.model.users.users.UserLocatorVO\", \"id\":\"-2764790703445493034\"}, \"display\":\"PerfTestUser3\", \"shortDisplay\":\"PerfTestUser3\", \"id\":\"-2764790703445493034\"}, \"type\":{\"class\":\"org.cyclos.model.banking.transfertypes.TransferTypeVO\", \"enabled\":true, \""
		"from\":{\"class\":\"org.cyclos.model.banking.accounttypes.AccountTypeVO\", \"global\":false, \"nature\":\"USER\", \"internalName\":\"user\", \"id\":\"-2764790703680374058\", \"name\":\"Member account\"}, \"to\":{\"class\":\"org.cyclos.model.banking.accounttypes.SystemAccountTypeVO\", \"limitType\":\"UNLIMITED\", \"global\":false, \"nature\":\"SYSTEM\", \"internalName\":\"debit\", \"id\":\"-2764790703747482922\", \"name\":\"Debit account\"}, \"nature\":\"PAYMENT\", \"requiresAuthorization\":false, "
		"\"ignoreAccountLimits\":false, \"allowFromCustomName\":false, \"allowToCustomName\":false, \"internalName\":\"user.toDebit\", \"id\":\"-2764790703579710762\", \"name\":\"Payment to Debit account\"}, \"description\":\"THIS IS TEXT DESCRIPTION\", \"amount\":\"1.00\", \"customValues\":[], \"confirmationPassword\":null}]}", 
		LAST);

	web_url("loadTranslations_7", 
		"URL=http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com/cyclos/Network01/content/loadTranslations?_k=04186c5b68794be61ffa6bc7fb4a478817386a94&cacheKey=04186c5b68794be61ffa6bc7fb4a478817386a94&languageId=-2764790703814591786&languageLastModified=&submodule=BANKING.TRANSACTIONS&submodule=BANKING.TRANSFERS&submodule=BANKING.AUTHORIZATIONS&submodule=BANKING.RATES&submodule=USERS.CONTACTS", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com/cyclos/Network01", 
		"Snapshot=t21.inf", 
		"Mode=HTML", 
		LAST);

	web_reg_find("Text=The payment was successful", 
		LAST);

	web_add_auto_header("Origin", 
		"http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com");

	web_custom_request("paymentService_3", 
		"URL=http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com/cyclos/Network01/web-rpc/paymentService", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com/cyclos/Network01", 
		"Snapshot=t22.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"operation\":\"getData\", \"params\":[\"-2764790704150136106\"]}", 
		LAST);

	/* CLICK HOME */

	web_reg_find("Text=Home", 
		LAST);

	web_revert_auto_header("Channel");

	web_revert_auto_header("Origin");

	web_revert_auto_header("Session-Prefix");

	web_add_auto_header("Session-Prefix", 
		"yIyo6NcOojsHItAx");

	lr_think_time(17);

	web_custom_request("initializationService_5", 
		"URL=http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com/cyclos/Network01/web-rpc/initializationService", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com/cyclos/Network01", 
		"Snapshot=t23.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"operation\":\"getHomeData\", \"params\":[]}", 
		LAST);

	/* CLICK ON ACCOUNT INFO */

	web_add_auto_header("Channel", 
		"main");

	web_add_auto_header("Origin", 
		"http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com");

	web_custom_request("accountService_5", 
		"URL=http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com/cyclos/Network01/web-rpc/accountService", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com/cyclos/Network01", 
		"Snapshot=t24.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"operation\":\"getAccountsSummary\", \"params\":[{\"class\":\"org.cyclos.model.users.users.UserVO\", \"id\":\"-2764790703445493034\"},null]}", 
		LAST);

	web_custom_request("accountService_6", 
		"URL=http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com/cyclos/Network01/web-rpc/accountService", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com/cyclos/Network01", 
		"Snapshot=t25.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"operation\":\"getAccountHistoryData\", \"params\":[{\"class\":\"org.cyclos.model.banking.accounts.AccountVO\", \"id\":\"-2764790703512601898\"},\"PARAM_NO_UNLIMITED\"]}", 
		LAST);

	web_custom_request("accountService_7", 
		"URL=http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com/cyclos/Network01/web-rpc/accountService", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com/cyclos/Network01", 
		"Snapshot=t26.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"operation\":\"getAccountHistoryStatus\", \"params\":[{\"class\":\"org.cyclos.model.banking.accounts.AccountHistoryQuery\", \"account\":{\"class\":\"org.cyclos.model.banking.accounts.AccountVO\", \"owner\":{\"class\":\"org.cyclos.model.users.users.UserVO\", \"display\":\"PerfTestUser3\", \"shortDisplay\":\"PerfTestUser3\", \"id\":\"-2764790703445493034\"}, \"type\":{\"class\":\"org.cyclos.model.banking.accounttypes.AccountTypeVO\", \"global\":false, \"nature\":\"USER\", \"internalName\":\""
		"user\", \"id\":\"-2764790703680374058\", \"name\":\"Member account\"}, \"active\":true, \"id\":\"-2764790703512601898\"}, \"usersWithImage\":false, \"orderBy\":\"DATE_DESC\", \"preselectedPeriod\":{\"class\":\"org.cyclos.model.utils.PeriodPreselectorOptionData\", \"name\":\"Last 12 months\", \"type\":\"PRESELECTED\", \"period\":{\"class\":\"org.cyclos.model.utils.DatePeriodDTO\", \"end\":\"2019-08-11T23:59:59.999+01:00\", \"begin\":\"2018-08-11T00:00:00.000+01:00\"}, \"defaultOption\":true}, \""
		"fromCurrentAccessClient\":false, \"includeGeneratedByAccessClient\":false, \"currentPage\":0, \"pageSize\":40, \"statuses\":[]}]}", 
		LAST);

	web_reg_find("Text=Member account", 
		LAST);

	web_custom_request("accountService_8", 
		"URL=http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com/cyclos/Network01/web-rpc/accountService", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com/cyclos/Network01", 
		"Snapshot=t27.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"operation\":\"searchAccountHistory\", \"params\":[{\"class\":\"org.cyclos.model.banking.accounts.AccountHistoryQuery\", \"account\":{\"class\":\"org.cyclos.model.banking.accounts.AccountVO\", \"owner\":{\"class\":\"org.cyclos.model.users.users.UserVO\", \"display\":\"PerfTestUser3\", \"shortDisplay\":\"PerfTestUser3\", \"id\":\"-2764790703445493034\"}, \"type\":{\"class\":\"org.cyclos.model.banking.accounttypes.AccountTypeVO\", \"global\":false, \"nature\":\"USER\", \"internalName\":\""
		"user\", \"id\":\"-2764790703680374058\", \"name\":\"Member account\"}, \"active\":true, \"id\":\"-2764790703512601898\"}, \"usersWithImage\":false, \"orderBy\":\"DATE_DESC\", \"preselectedPeriod\":{\"class\":\"org.cyclos.model.utils.PeriodPreselectorOptionData\", \"name\":\"Last 12 months\", \"type\":\"PRESELECTED\", \"period\":{\"class\":\"org.cyclos.model.utils.DatePeriodDTO\", \"end\":\"2019-08-11T23:59:59.999+01:00\", \"begin\":\"2018-08-11T00:00:00.000+01:00\"}, \"defaultOption\":true}, \""
		"fromCurrentAccessClient\":false, \"includeGeneratedByAccessClient\":false, \"currentPage\":0, \"pageSize\":40, \"statuses\":[]}]}", 
		LAST);

	/* CLICK ON LOGOUT */

	lr_think_time(17);

	web_custom_request("loginService", 
		"URL=http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com/cyclos/Network01/web-rpc/loginService", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com/cyclos/Network01", 
		"Snapshot=t28.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"operation\":\"logout\", \"params\":[]}", 
		LAST);

	web_revert_auto_header("Session-Prefix");

	web_custom_request("initializationService_6", 
		"URL=http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com/cyclos/Network01/web-rpc/initializationService", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com/cyclos/Network01", 
		"Snapshot=t29.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"operation\":\"getInitializationData\", \"params\":[null,null]}", 
		LAST);

	web_reg_find("Text=Welcome to Network 01", 
		LAST);

	web_custom_request("initializationService_7", 
		"URL=http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com/cyclos/Network01/web-rpc/initializationService", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://cyclos-dev-loadbalancer-568615165.eu-west-1.elb.amazonaws.com/cyclos/Network01", 
		"Snapshot=t30.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"operation\":\"getHomeData\", \"params\":[]}", 
		LAST);

	return 0;
}