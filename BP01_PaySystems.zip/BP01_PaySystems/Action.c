/*Declaration of variable and datatype for verification of debited amount written in logic at Transaction BP01_90_AccountInfo2*/

float x,y,z;
double atof( const char *string); /* Explicit declaration */

Action()
{

	/* Application Launch and Login code is in vuser_init and Logout code is in vuser_end section and will be executed once per user to simulate real time behaviour */

web_add_header("Session-Prefix","<c_sessionID>");

/*Click on Account Info Title*/

lr_start_transaction("BP01_04_AccountInfo");

	web_url("loadTranslations_3",
		"URL=<p_ServerURL>/cyclos/Network01/content/loadTranslations?_k=<c_kID>&cacheKey=<c_kID>&languageId=<c_languageId>&languageLastModified=&submodule=BANKING.ACCOUNTS&submodule=BANKING.TRANSFERS",
		"TargetFrame=",
		"Resource=0",
		"RecContentType=application/json",
		"Referer=<p_ServerURL>/cyclos/Network01",
		"Snapshot=t9.inf",
		"Mode=HTML",
		LAST);

web_add_header("Origin","<p_ServerURL>");

web_add_header("Session-Prefix","<c_sessionID>");
	
		web_reg_save_param_json(
		"ParamName=c_beforebalance",
		"QueryString=$.result.[0].status.availableBalance",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=No",
		LAST);
	
	web_custom_request("accountService",
		"URL=<p_ServerURL>/cyclos/Network01/web-rpc/accountService",
		"Method=POST",
		"TargetFrame=",
		"Resource=0",
		"RecContentType=application/json",
		"Referer=<p_ServerURL>/cyclos/Network01",
		"Snapshot=t10.inf",
		"Mode=HTML",
		"EncType=application/json",
		"Body={\"operation\":\"getAccountsSummary\", \"params\":[{\"class\":\"org.cyclos.model.users.users.UserVO\", \"id\":\"<c_userID_1>\"},null]}",
		LAST);

web_add_header("Session-Prefix","<c_sessionID>");
	
	web_url("loadTranslations_4",
		"URL=<p_ServerURL>/cyclos/Network01/content/loadTranslations?_k=<c_kID>&cacheKey=<c_kID>&languageId=<c_languageId>&languageLastModified=&submodule=BANKING.ACCOUNTS&submodule=BANKING.TRANSACTIONS&submodule=BANKING.TRANSFERS&submodule=BANKING.RATES&submodule=USERS.USERS",
		"TargetFrame=",
		"Resource=0",
		"RecContentType=application/json",
		"Referer=<p_ServerURL>/cyclos/Network01",
		"Snapshot=t11.inf",
		"Mode=HTML",
		LAST);

web_add_auto_header("Origin","<p_ServerURL>");

web_add_header("Session-Prefix","<c_sessionID>");
	
	web_custom_request("accountService_2",
		"URL=<p_ServerURL>/cyclos/Network01/web-rpc/accountService",
		"Method=POST",
		"TargetFrame=",
		"Resource=0",
		"RecContentType=application/json",
		"Referer=<p_ServerURL>/cyclos/Network01",
		"Snapshot=t12.inf",
		"Mode=HTML",
		"EncType=application/json",
		"Body={\"operation\":\"getAccountHistoryData\", \"params\":[{\"class\":\"org.cyclos.model.banking.accounts.AccountVO\", \"id\":\"<c_userId_2>\"},\"PARAM_NO_UNLIMITED\"]}",
		LAST);

web_add_header("Session-Prefix","<c_sessionID>");

web_reg_find("Fail=NotFound","Search=Body","SaveCount=accountinfo_cnt1","Text=Member account",LAST);

	web_custom_request("accountService_3",
		"URL=<p_ServerURL>/cyclos/Network01/web-rpc/accountService",
		"Method=POST",
		"TargetFrame=",
		"Resource=0",
		"RecContentType=application/json",
		"Referer=<p_ServerURL>/cyclos/Network01",
		"Snapshot=t13.inf",
		"Mode=HTML",
		"EncType=application/json",
		"Body={\"operation\":\"searchAccountHistory\", \"params\":[{\"class\":\"org.cyclos.model.banking.accounts.AccountHistoryQuery\", \"account\":{\"class\":\"org.cyclos.model.banking.accounts.AccountVO\", \"owner\":{\"class\":\"org.cyclos.model.users.users.UserVO\", \"display\":\"<p_username>\", \"shortDisplay\":\"<p_username>\", \"id\":\"<c_userID_1>\"}, \"type\":{\"class\":\"org.cyclos.model.banking.accounttypes.AccountTypeVO\", \"global\":false, \"nature\":\"USER\", \"internalName\":\"user\", \"id\":\"<c_userID_3>\", \"name\":\"Member account\"}, \"active\":true, \"id\":\"<c_userId_2>\"}, \"usersWithImage\":false, \"orderBy\":\"DATE_DESC\", \"preselectedPeriod\":{\"class\":\"org.cyclos.model.utils.PeriodPreselectorOptionData\", \"name\":\"Last 12 months\", \"type\":\"PRESELECTED\", \"period\":{\"class\":\"org.cyclos.model.utils.DatePeriodDTO\", \"end\":\"<p_date>T23:59:59.999+01:00\", \"begin\":\"<p_date2>T00:00:00.000+01:00\"}, \"defaultOption\":true}, \"fromCurrentAccessClient\":false, \"includeGenerate"
		"dByAccessClient\":false, \"currentPage\":0, \"pageSize\":40, \"statuses\":[]}]}",
		LAST);

web_add_header("Session-Prefix","<c_sessionID>");
	
web_add_header("Origin","<p_ServerURL>");

	web_custom_request("accountService_4",
		"URL=<p_ServerURL>/cyclos/Network01/web-rpc/accountService",
		"Method=POST",
		"TargetFrame=",
		"Resource=0",
		"RecContentType=application/json",
		"Referer=<p_ServerURL>/cyclos/Network01",
		"Snapshot=t14.inf",
		"Mode=HTML",
		"EncType=application/json",
		"Body={\"operation\":\"getAccountHistoryStatus\", \"params\":[{\"class\":\"org.cyclos.model.banking.accounts.AccountHistoryQuery\", \"account\":{\"class\":\"org.cyclos.model.banking.accounts.AccountVO\", \"owner\":{\"class\":\"org.cyclos.model.users.users.UserVO\", \"display\":\"<p_username>\", \"shortDisplay\":\"<p_username>\", \"id\":\"<c_userID_1>\"}, \"type\":{\"class\":\"org.cyclos.model.banking.accounttypes.AccountTypeVO\", \"global\":false, \"nature\":\"USER\", \"internalName\":\"user\", \"id\":\"<c_userID_3>\", \"name\":\"Member account\"}, \"active\":true, \"id\":\"<c_userId_2>\"}, \"usersWithImage\":false, \"orderBy\":\"DATE_DESC\", \"preselectedPeriod\":{\"class\":\"org.cyclos.model.utils.PeriodPreselectorOptionData\", \"name\":\"Last 12 months\", \"type\":\"PRESELECTED\", \"period\":{\"class\":\"org.cyclos.model.utils.DatePeriodDTO\", \"end\":\"<p_date>T23:59:59.999+01:00\", \"begin\":\"<p_date2>T00:00:00.000+01:00\"}, \"defaultOption\":true}, \"fromCurrentAccessClient\":false, \"includeGener"
		"atedByAccessClient\":false, \"currentPage\":0, \"pageSize\":40, \"statuses\":[]}]}",
		LAST);


if(atoi(lr_eval_string("<accountinfo_cnt1>"))>0)
	{
lr_end_transaction("BP01_04_AccountInfo",LR_PASS);
	}
	else
	{

lr_end_transaction("BP01_04_AccountInfo",LR_FAIL);
lr_output_message("Account info page load failed at = %s",lr_eval_string("<p_timestamp>"));
	}
lr_think_time(5);


web_add_auto_header("Session-Prefix","<c_sessionID>");

lr_start_transaction("BP01_05_PaymentToSystem");

	web_url("loadTranslations_5",
		"URL=<p_ServerURL>/cyclos/Network01/content/loadTranslations?_k=<c_kID>&cacheKey=<c_kID>&languageId=<c_languageId>&languageLastModified=&submodule=BANKING.TRANSACTIONS&submodule=BANKING.TRANSFERS&submodule=BANKING.RATES&submodule=GENERAL.UI",
		"TargetFrame=",
		"Resource=0",
		"RecContentType=application/json",
		"Referer=<p_ServerURL>/cyclos/Network01",
		"Snapshot=t15.inf",
		"Mode=HTML",
		LAST);

web_add_auto_header("Origin","<p_ServerURL>");

web_add_header("Session-Prefix","<c_sessionID>");

web_reg_find("Fail=NotFound","Search=Body","SaveCount=pmt2sys_cnt","Text=Payment to Debit account",LAST);
	
	web_custom_request("transactionService",
		"URL=<p_ServerURL>/cyclos/Network01/web-rpc/transactionService",
		"Method=POST",
		"TargetFrame=",
		"Resource=0",
		"RecContentType=application/json",
		"Referer=<p_ServerURL>/cyclos/Network01",
		"Snapshot=t16.inf",
		"Mode=HTML",
		"EncType=application/json",
		"Body={\"operation\":\"getPaymentData\", \"params\":[{\"class\":\"org.cyclos.model.users.users.UserVO\", \"id\":\"<c_userID_1>\"},\"SYSTEM\",null]}",
		LAST);

web_add_header("Session-Prefix","<c_sessionID>");
	
	web_custom_request("transactionService_2",
		"URL=<p_ServerURL>/cyclos/Network01/web-rpc/transactionService",
		"Method=POST",
		"TargetFrame=",
		"Resource=0",
		"RecContentType=application/json",
		"Referer=<p_ServerURL>/cyclos/Network01",
		"Snapshot=t17.inf",
		"Mode=HTML",
		"EncType=application/json",
		"Body={\"operation\":\"getPaymentTypeData\", \"params\":[{\"class\":\"org.cyclos.model.users.users.UserVO\", \"display\":\"<p_username>\", \"shortDisplay\":\"<p_username>\", \"id\":\"<c_userID_1>\"},\"SYSTEM\",{\"class\":\"org.cyclos.model.banking.transfertypes.TransferTypeWithCurrencyVO\", \"currency\":{\"class\":\"org.cyclos.model.banking.currencies.CurrencyVO\", \"symbol\":\"U\", \"precision\":2, \"global\":false, \"prefix\":\"U \", \"internalName\":\"unit\", \"id\":\"<c_unitID>\", \"name\":\"Units\"}, \"enabled\":true, \"from\":{\"class\":\"org.cyclos.model.banking.accounttypes.AccountTypeVO\", \"global\":false, \"nature\":\"USER\", \"internalName\":\"user\", \"id\":\"<c_userID_3>\", \"name\":\"Member account\"}, \"to\":{\"class\":\"org.cyclos.model.banking.accounttypes.SystemAccountTypeVO\", \"limitType\":\"UNLIMITED\", \"global\":false, \"nature\":\"SYSTEM\", \"internalName\":\"debit\", \"id\":\"<c_unitID>\", \"name\":\"Debit account\"}, \"nature\":\"PAYMENT\", \"requiresAuthorization\":false, \"ignor"
		"eAccountLimits\":false, \"allowFromCustomName\":false, \"allowToCustomName\":false, \"internalName\":\"user.toDebit\", \"id\":\"<c_usertodebitID>\", \"name\":\"Payment to Debit account\"}]}",
		LAST);

if(atoi(lr_eval_string("<pmt2sys_cnt>"))>0)
	{
lr_end_transaction("BP01_05_PaymentToSystem",LR_PASS);
	}
	else
	{

lr_end_transaction("BP01_05_PaymentToSystem",LR_FAIL);
lr_output_message("Payment to Sys page failed to load = %s",lr_eval_string("<p_timestamp>"));
	}
	
lr_think_time(5);

web_add_header("Session-Prefix","<c_sessionID>");

lr_start_transaction("BP01_06_Submitpayment");
	
	web_custom_request("paymentService",
		"URL=<p_ServerURL>/cyclos/Network01/web-rpc/paymentService",
		"Method=POST",
		"TargetFrame=",
		"Resource=0",
		"RecContentType=application/json",
		"Referer=<p_ServerURL>/cyclos/Network01",
		"Snapshot=t18.inf",
		"Mode=HTML",
		"EncType=application/json",
		"Body={\"operation\":\"preview\", \"params\":[{\"class\":\"org.cyclos.model.banking.transactions.PerformPaymentDTO\", \"from\":{\"class\":\"org.cyclos.model.users.users.UserVO\", \"display\":\"<p_username>\", \"shortDisplay\":\"<p_username>\", \"id\":\"<c_userID_1>\"}, \"to\":\"SYSTEM\", \"amount\":\"<p_randamt>.00\", \"type\":{\"class\":\"org.cyclos.model.banking.transfertypes.TransferTypeWithCurrencyVO\", \"currency\":{\"class\":\"org.cyclos.model.banking.currencies.CurrencyVO\", \"symbol\":\"U\", \"precision\":2, \"global\":false, \"prefix\":\"U \", \"internalName\":\"unit\", \"id\":\"<c_unitID>\", \"name\":\"Units\"}, \"enabled\":true, \"from\":{\"class\":\"org.cyclos.model.banking.accounttypes.AccountTypeVO\", \"global\":false, \"nature\":\"USER\", \"internalName\":\"user\", \"id\":\"<c_userID_3>\", \"name\":\"Member account\"}, \"to\":{\"class\":\"org.cyclos.model.banking.accounttypes.SystemAccountTypeVO\", \"limitType\":\"UNLIMITED\", \"global\":false, \"nature\":\"SYSTEM\", \"internalName\":\"debit\", \"id\":"
		"\"<c_unitID>\", \"name\":\"Debit account\"}, \"nature\":\"PAYMENT\", \"requiresAuthorization\":false, \"ignoreAccountLimits\":false, \"allowFromCustomName\":false, \"allowToCustomName\":false, \"internalName\":\"user.toDebit\", \"id\":\"<c_usertodebitID>\", \"name\":\"Payment to Debit account\"}, \"description\":\"THIS IS TEXT DESCRIPTION number <p_counter>\", \"customValues\":[]}]}",
		LAST);


web_add_header("Session-Prefix","<c_sessionID>");


web_reg_find("Fail=NotFound","Search=Body","SaveCount=submitpmt_cnt","Text=Payment review",LAST);

web_add_auto_header("Session-Prefix","<c_sessionID>");

	web_url("loadTranslations_6",
		"URL=<p_ServerURL>/cyclos/Network01/content/loadTranslations?_k=<c_kID>&cacheKey=<c_kID>&languageId=<c_languageId>&languageLastModified=&submodule=BANKING.TRANSFERS&submodule=BANKING.RATES&submodule=BANKING.TRANSACTIONS&submodule=ACCESS.PASSWORD_TYPES",
		"TargetFrame=",
		"Resource=0",
		"RecContentType=application/json",
		"Referer=<p_ServerURL>/cyclos/Network01",
		"Snapshot=t19.inf",
		"Mode=HTML",
		LAST);

if(atoi(lr_eval_string("<submitpmt_cnt>"))>0)
	{
lr_end_transaction("BP01_06_Submitpayment",LR_PASS);
	}
	else
	{

lr_end_transaction("BP01_06_Submitpayment",LR_FAIL);
lr_output_message("Payment Submission failed at = %s",lr_eval_string("<p_timestamp>"));
	}
	
lr_think_time(5);
	
	/* CONFIRM ON PAYMENT REVIEW */

web_add_header("Session-Prefix","<c_sessionID>");
	
web_add_header("Origin","<p_ServerURL>");
	
/*Correlation comment - Do not change!  Original value='-2764790704150136106' Name ='c_paymentID' Type ='Manual'*/
	web_reg_save_param_json(
		"ParamName=c_paymentID",
		"QueryString=$.result.id",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=No",
		LAST);

lr_start_transaction("BP01_07_ConfirmPayment");

	web_custom_request("paymentService_2",
		"URL=<p_ServerURL>/cyclos/Network01/web-rpc/paymentService",
		"Method=POST",
		"TargetFrame=",
		"Resource=0",
		"RecContentType=application/json",
		"Referer=<p_ServerURL>/cyclos/Network01",
		"Snapshot=t20.inf",
		"Mode=HTML",
		"EncType=application/json",
		"Body={\"operation\":\"perform\", \"params\":[{\"class\":\"org.cyclos.model.banking.transactions.PerformPaymentDTO\", \"to\":\"SYSTEM\", \"from\":{\"class\":\"org.cyclos.model.users.users.UserVO\", \"locator\":{\"class\":\"org.cyclos.model.users.users.UserLocatorVO\", \"id\":\"<c_userID_1>\"}, \"display\":\"<p_username>\", \"shortDisplay\":\"<p_username>\", \"id\":\"<c_userID_1>\"}, \"type\":{\"class\":\"org.cyclos.model.banking.transfertypes.TransferTypeVO\", \"enabled\":true, \"from\":{\"class\":\"org.cyclos.model.banking.accounttypes.AccountTypeVO\", \"global\":false, \"nature\":\"USER\", \"internalName\":\"user\", \"id\":\"<c_userID_3>\", \"name\":\"Member account\"}, \"to\":{\"class\":\"org.cyclos.model.banking.accounttypes.SystemAccountTypeVO\", \"limitType\":\"UNLIMITED\", \"global\":false, \"nature\":\"SYSTEM\", \"internalName\":\"debit\", \"id\":\"<c_unitID>\", \"name\":\"Debit account\"}, \"nature\":\"PAYMENT\", \"requiresAuthorization\":false, \"ignoreAccountLimits\":false, \"allowFromCustomName"
		"\":false, \"allowToCustomName\":false, \"internalName\":\"user.toDebit\", \"id\":\"<c_usertodebitID>\", \"name\":\"Payment to Debit account\"}, \"description\":\"THIS IS TEXT DESCRIPTION\", \"amount\":\"<p_randamt>.00\", \"customValues\":[], \"confirmationPassword\":null}]}",
		LAST);

web_reg_find("Fail=NotFound","Search=Body","SaveCount=cnfrmpmt_cnt","Text=The payment was successful",LAST);

web_url("loadTranslations_7",
		"URL=<p_ServerURL>/cyclos/Network01/content/loadTranslations?_k=<c_kID>&cacheKey=<c_kID>&languageId=<c_languageId>&languageLastModified=&submodule=BANKING.TRANSACTIONS&submodule=BANKING.TRANSFERS&submodule=BANKING.AUTHORIZATIONS&submodule=BANKING.RATES&submodule=USERS.CONTACTS",
		"TargetFrame=",
		"Resource=0",
		"RecContentType=application/json",
		"Referer=<p_ServerURL>/cyclos/Network01",
		"Snapshot=t21.inf",
		"Mode=HTML",
		LAST);

web_add_auto_header("Origin","<p_ServerURL>");

	web_custom_request("paymentService_3",
		"URL=<p_ServerURL>/cyclos/Network01/web-rpc/paymentService",
		"Method=POST",
		"TargetFrame=",
		"Resource=0",
		"RecContentType=application/json",
		"Referer=<p_ServerURL>/cyclos/Network01",
		"Snapshot=t22.inf",
		"Mode=HTML",
		"EncType=application/json",
		"Body={\"operation\":\"getData\", \"params\":[\"<c_paymentID>\"]}",
		LAST);

if(atoi(lr_eval_string("<cnfrmpmt_cnt>"))>0)
	{
lr_end_transaction("BP01_07_ConfirmPayment",LR_PASS);
	}
	else
	{

lr_end_transaction("BP01_07_ConfirmPayment",LR_FAIL);
lr_output_message("Payment Confirmation failed at = %s",lr_eval_string("<p_timestamp>"));
	}
	
lr_think_time(5);

	/* CLICK HOME */

web_reg_find("Fail=NotFound","Search=Body","SaveCount=home_cnt","Text=Home",LAST);

web_add_auto_header("Session-Prefix","<c_sessionID>");

lr_start_transaction("BP01_08_Home");

	web_custom_request("initializationService_5", 
		"URL=<p_ServerURL>/cyclos/Network01/web-rpc/initializationService", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=<p_ServerURL>/cyclos/Network01", 
		"Snapshot=t23.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"operation\":\"getHomeData\", \"params\":[]}", 
		LAST);

	if(atoi(lr_eval_string("<home_cnt>"))>0)
	{
lr_end_transaction("BP01_08_Home",LR_PASS);
	}
	else
	{

lr_end_transaction("BP01_08_Home",LR_FAIL);
lr_output_message("Navigation to homepage failed at = %s",lr_eval_string("<p_timestamp>"));
	}
lr_think_time(5);

	/* CLICK ON ACCOUNT INFO */

web_add_auto_header("Origin","<p_ServerURL>");

lr_start_transaction("BP01_09_AccountInfo2");

	web_custom_request("accountService_5",
		"URL=<p_ServerURL>/cyclos/Network01/web-rpc/accountService",
		"Method=POST",
		"TargetFrame=",
		"Resource=0",
		"RecContentType=application/json",
		"Referer=<p_ServerURL>/cyclos/Network01",
		"Snapshot=t24.inf",
		"Mode=HTML",
		"EncType=application/json",
		"Body={\"operation\":\"getAccountsSummary\", \"params\":[{\"class\":\"org.cyclos.model.users.users.UserVO\", \"id\":\"<c_userID_1>\"},null]}",
		LAST);

	web_custom_request("accountService_6",
		"URL=<p_ServerURL>/cyclos/Network01/web-rpc/accountService",
		"Method=POST",
		"TargetFrame=",
		"Resource=0",
		"RecContentType=application/json",
		"Referer=<p_ServerURL>/cyclos/Network01",
		"Snapshot=t25.inf",
		"Mode=HTML",
		"EncType=application/json",
		"Body={\"operation\":\"getAccountHistoryData\", \"params\":[{\"class\":\"org.cyclos.model.banking.accounts.AccountVO\", \"id\":\"<c_userId_2>\"},\"PARAM_NO_UNLIMITED\"]}",
		LAST);

		web_reg_save_param_json(
		"ParamName=c_afterAvailbalance",
		"QueryString=$.result.availableBalance",
		SEARCH_FILTERS,
		"Scope=Body",
		"IgnoreRedirections=No",
		LAST);
	
	web_custom_request("accountService_7",
		"URL=<p_ServerURL>/cyclos/Network01/web-rpc/accountService",
		"Method=POST",
		"TargetFrame=",
		"Resource=0",
		"RecContentType=application/json",
		"Referer=<p_ServerURL>/cyclos/Network01",
		"Snapshot=t26.inf",
		"Mode=HTML",
		"EncType=application/json",
		"Body={\"operation\":\"getAccountHistoryStatus\", \"params\":[{\"class\":\"org.cyclos.model.banking.accounts.AccountHistoryQuery\", \"account\":{\"class\":\"org.cyclos.model.banking.accounts.AccountVO\", \"owner\":{\"class\":\"org.cyclos.model.users.users.UserVO\", \"display\":\"<p_username>\", \"shortDisplay\":\"<p_username>\", \"id\":\"<c_userID_1>\"}, \"type\":{\"class\":\"org.cyclos.model.banking.accounttypes.AccountTypeVO\", \"global\":false, \"nature\":\"USER\", \"internalName\":\"user\", \"id\":\"<c_userID_3>\", \"name\":\"Member account\"}, \"active\":true, \"id\":\"<c_userId_2>\"}, \"usersWithImage\":false, \"orderBy\":\"DATE_DESC\", \"preselectedPeriod\":{\"class\":\"org.cyclos.model.utils.PeriodPreselectorOptionData\", \"name\":\"Last 12 months\", \"type\":\"PRESELECTED\", \"period\":{\"class\":\"org.cyclos.model.utils.DatePeriodDTO\", \"end\":\"<p_date>T23:59:59.999+01:00\", \"begin\":\"<p_date2>T00:00:00.000+01:00\"}, \"defaultOption\":true}, \"fromCurrentAccessClient\":false, \"includeGener"
		"atedByAccessClient\":false, \"currentPage\":0, \"pageSize\":40, \"statuses\":[]}]}",
		LAST);

web_reg_find("Fail=NotFound","Search=Body","SaveCount=accountinfo_cnt2","Text=Member account",LAST);

	web_custom_request("accountService_8",
		"URL=<p_ServerURL>/cyclos/Network01/web-rpc/accountService",
		"Method=POST",
		"TargetFrame=",
		"Resource=0",
		"RecContentType=application/json",
		"Referer=<p_ServerURL>/cyclos/Network01",
		"Snapshot=t27.inf",
		"Mode=HTML",
		"EncType=application/json",
		"Body={\"operation\":\"searchAccountHistory\", \"params\":[{\"class\":\"org.cyclos.model.banking.accounts.AccountHistoryQuery\", \"account\":{\"class\":\"org.cyclos.model.banking.accounts.AccountVO\", \"owner\":{\"class\":\"org.cyclos.model.users.users.UserVO\", \"display\":\"<p_username>\", \"shortDisplay\":\"<p_username>\", \"id\":\"<c_userID_1>\"}, \"type\":{\"class\":\"org.cyclos.model.banking.accounttypes.AccountTypeVO\", \"global\":false, \"nature\":\"USER\", \"internalName\":\"user\", \"id\":\"<c_userID_3>\", \"name\":\"Member account\"}, \"active\":true, \"id\":\"<c_userId_2>\"}, \"usersWithImage\":false, \"orderBy\":\"DATE_DESC\", \"preselectedPeriod\":{\"class\":\"org.cyclos.model.utils.PeriodPreselectorOptionData\", \"name\":\"Last 12 months\", \"type\":\"PRESELECTED\", \"period\":{\"class\":\"org.cyclos.model.utils.DatePeriodDTO\", \"end\":\"<p_date>T23:59:59.999+01:00\", \"begin\":\"<p_date2>T00:00:00.000+01:00\"}, \"defaultOption\":true}, \"fromCurrentAccessClient\":false, \"includeGenerate"
		"dByAccessClient\":false, \"currentPage\":0, \"pageSize\":40, \"statuses\":[]}]}",
		LAST);

/*Logic to verify that amount is debited, passing the transaction if the "available balace is = previous balance - amount debited" */

	 x = atof(lr_eval_string("<c_afterAvailbalance>"));
	 y = atof(lr_eval_string("<c_beforebalance>"));
	 z = atof(lr_eval_string("<p_randamt>"));
	
	 lr_output_message("Value of x=%.2f, y=%.2f, z=%.2f", x,y,z);
	
	if(x = y-z)
	{
lr_end_transaction("BP01_09_AccountInfo2",LR_PASS);
lr_output_message("Account succesfully debited at = %s",lr_eval_string("<p_timestamp>"));
	}
	else
	{

lr_end_transaction("BP01_09_AccountInfo2",LR_FAIL);
lr_output_message("Account not debited at = %s",lr_eval_string("<p_timestamp>"));
	}
	/* CLICK ON LOGOUT */
	
lr_think_time(5);


	return 0;
}