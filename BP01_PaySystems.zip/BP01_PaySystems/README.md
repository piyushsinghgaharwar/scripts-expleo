# piyush-repo-for-expleo
Below points provides information on scripts commited in this repo
1. Attached scripts are user journey BP01 (Paysystem) and BP02 (CreateAd)
2. Scripts are prepared in HP Loadrunner tool version 12.60 but since they are prepared in HTTP protocol , scripts should get executed in lower version.
3. The start and End of Transactions can be found in the scripts as "lr_start_transaction" and "lr_end_transactions" respectively
4. web_reg_find function is used to capture all the possible text checkpoints from response of the particular requests
5. web_reg_save_param/web_reg_save_param_ex/web_reg_save_param_json are used in the scripts to capture dynamic values from server response
6. if else logic is used to pass/fail transaction wherever necessary.

