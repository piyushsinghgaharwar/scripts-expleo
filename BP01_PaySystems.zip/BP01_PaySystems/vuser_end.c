vuser_end()
{
		
lr_start_transaction("BP01_10_LogOut");

	web_custom_request("loginService", 
		"URL=<p_ServerURL>/cyclos/Network01/web-rpc/loginService", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=<p_ServerURL>/cyclos/Network01", 
		"Snapshot=t28.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"operation\":\"logout\", \"params\":[]}", 
		LAST);

web_revert_auto_header("Session-Prefix");

	web_custom_request("initializationService_6", 
		"URL=<p_ServerURL>/cyclos/Network01/web-rpc/initializationService", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=<p_ServerURL>/cyclos/Network01", 
		"Snapshot=t29.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"operation\":\"getInitializationData\", \"params\":[null,null]}", 
		LAST);

web_reg_find("Fail=NotFound","Search=Body","SaveCount=homepg_cnt","Text=Welcome to Network 01",LAST);

	web_custom_request("initializationService_7", 
		"URL=<p_ServerURL>/cyclos/Network01/web-rpc/initializationService", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=<p_ServerURL>/cyclos/Network01", 
		"Snapshot=t30.inf", 
		"Mode=HTML", 
		"EncType=application/json", 
		"Body={\"operation\":\"getHomeData\", \"params\":[]}", 
		LAST);


if(atoi(lr_eval_string("<homepg_cnt>"))>0)
	{
lr_end_transaction("BP01_10_LogOut",LR_PASS);
	}
	else
	{

lr_end_transaction("BP01_10_LogOut",LR_FAIL);
lr_output_message("Applicaion Login failed at = %s",lr_eval_string("<p_timestamp>"));
	}
	
	return 0;
}
